AT24 SESSION RANGE BOX - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- The Asian session range as a box every day, with the state (inside, broke up, broke down), box size against the median, the days analysed, how the first break went (up / down / none), how often a break held to the day end and how often it ran at least 1x the box, with a dashboard table.
- Hours are in GMT/UTC; the statistics use the history your TradingView plan loads (60 days by default).

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (1 hour or lower, any symbol with an Asian session).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Session_Range_Box.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 60 days: first break up 40%, down 48%, none 12%; held 60%; ran 1x 36%). Not tested: live-money use. Numbers differ by feed and period; they are descriptive and show no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
