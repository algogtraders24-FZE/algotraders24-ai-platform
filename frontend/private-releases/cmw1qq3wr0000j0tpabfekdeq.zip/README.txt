AT24 FVG ZONES - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- Every three-bar fair value gap on closed bars (bullish if the low of the third bar is above the high of the first, bearish the other way), filtered by size in ATR, drawn as zones on your chart.
- Only open (not yet filled) gaps are drawn; gaps that price already touched are labelled. The gap exists only after its third bar has closed, so nothing repaints.
- A dashboard with the number of open gaps and the nearest open gap above and below price.
- Statistics on YOUR symbol and broker data: how often and how fast price came back into a gap within 50 bars, how often it filled it completely, and the same measure for a control level at the same distance from another bar's close.
- Optional alert when a new gap forms (bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the FVG Zones indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_FvgZones_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_FvgZones_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The gaps and statistics match an independent Python calculation (all 693 gaps identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, last 8,000 closed bars, about 790 gaps (minimum 0.3 ATR): price came back into a gap within 50 bars about 89% of the time (median 2 bars) and filled it completely about 78%. A control level at the same distance from another bar's close was revisited about 89%: a gap is no stronger a magnet than any other level at that distance. Descriptive only, NOT an edge. The ATR filter and window change the numbers.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
