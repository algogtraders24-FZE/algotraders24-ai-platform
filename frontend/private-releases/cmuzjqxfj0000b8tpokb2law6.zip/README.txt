XXX GOLD v3.02  -  Multi-module breakout EA for Gold (XAUUSD), M15
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES IN THIS DOWNLOAD
  XXXGOLD.ex5                    the Expert Advisor
  XXXGOLD_tested_settings.set    the EXACT inputs of the backtest the marketplace evidence is based on

INSTALL (3 minutes)
 1. MetaTrader 5: File > Open Data Folder > MQL5 > Experts: copy XXXGOLD.ex5 there (refresh the Navigator).
 2. Open an XAUUSD chart on M15 and drag XXXGOLD onto it. Allow Algo Trading.
 3. Inputs tab > Load > XXXGOLD_tested_settings.set to reproduce the tested configuration, then set the lot
    inputs to a size that is right for your account (see below).

IMPORTANT - READ BEFORE USING
 * THE TESTED SETTINGS DIFFER FROM THE EA DEFAULTS. The backtest ran with auto-lot-growth ON (InpAutoLotGrowth),
   a lot cap of 0.10 (InpMaxLot), the daily-loss limit ON and a break-even trigger of 12 pips. The EA's built-in
   defaults are growth OFF, no cap, daily-loss limit OFF, trigger 10 pips, fixed lot 0.01.
 * THE TESTED RUN TRADED 0.10 LOT THROUGHOUT: with growth on and a 10,000 deposit the lot is at its 0.10 cap from
   the first trade. Profit and drawdown scale with lot size - on a small account 0.10 lot on gold is a large risk.
 * AUTO-LOT GROWTH raises the lot by InpAutoLotStepSize for every InpAutoLotBalanceStep of balance above
   InpAutoLotBaseBalance, up to InpMaxLot. Keep InpMaxLot at a level you can afford.
 * PIPS: the stop loss, take profit, break-even and trailing inputs are in the EA's own "pip" units for gold (see the
   input names, e.g. InpGoldPipStopLoss=20). Check how that maps to price on YOUR broker's XAUUSD digits.
 * THE REPORT'S UNITS: the tester report this evidence comes from prints its currency as "profit in pips". The
   marketplace shows the report's figures exactly as the report states them; check the money value of a trade
   on your own broker/account before relying on any figure.
 * SYMBOL: tested on Exness "XAUUSD". Other brokers name it XAUUSD.m / GOLD etc.; check contract size, minimum
   lot and spread (the spread shield uses points - InpMaxSpreadPoints).
 * PENDING-ORDER BREAKOUT EA: BUY STOP / SELL STOP orders for up to 5 modules (Nova, Apex, Zenith, Pulse,
   Eclipse) at the same time; the tested run reached 9 simultaneous positions. Broker minimum stop distance,
   spread and slippage can change results a lot at this trade frequency.
 * The tester run used only 37% real ticks. Start on a DEMO account.
 * Past performance is not a guarantee of future results. Trading leveraged products is risky; this is not
   financial advice.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
