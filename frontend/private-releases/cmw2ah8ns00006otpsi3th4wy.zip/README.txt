AT24 ROUND LEVELS - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- A grid of round-number levels at three steps you choose (10, 50 and 100 by default, suited to gold), with the nearest level above and below price and the distance to each.
- Statistics on YOUR symbol and broker data (last 8,000 bars): for each step, how many times price touched a round level, how often it bounced (moved 1 ATR away before moving 1 ATR through the level, within 20 bars) and how often it broke through - each next to the same measure on control levels half a step away, so you can see whether round numbers really behave differently.
- Optional alerts when price touches a level (bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Round Levels indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_RoundLevels_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_RoundLevels_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The ATR, all six scans (events, bounce, break, neither) for real and control levels match an independent Python calculation (identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, last 8,000 bars: at the 10-dollar step (n about 2,350 touches) price bounced about 49% of the time against about 50% at control levels, and broke through about 49% against 48%. At the 50-dollar step (n about 460) bounce 46% against 49% and break 52% against 48%. At the 100-dollar step (n about 220) bounce 47% against 44% and break 51% against 53%. On another broker feed the 10 / 50 / 100 steps gave 49.7 / 48.0 / 49.1% against 50.2 / 49.6 / 47.0%. Price did not react differently at round numbers than at arbitrary levels. Descriptive only, NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
