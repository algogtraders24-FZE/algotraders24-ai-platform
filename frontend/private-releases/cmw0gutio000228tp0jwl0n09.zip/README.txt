AT24 REGIME PULSE - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- Regime label (TREND, STRONG TREND, RANGE, CHOP, QUIET, MIXED), trend quality (Efficiency Ratio 0-1), volatility rank (ATR percentile 0-100), session, and a spread cost ratio when you enter your typical spread.
- A coloured histogram with the volatility rank line in its own pane, plus a dashboard table.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Regime_Pulse.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- TradingView has no tick spread, so the Spread / ATR row uses the spread you type in the inputs.
- It describes the CURRENT state only. In our own check the regimes did NOT persist (next-20-bar Efficiency Ratio about 0.21-0.24 in every regime).
- Tested: compiles and renders in the Pine Editor. Not tested: live-money use.
- Context tool. Not a signal. Past conditions do not predict future results. Not financial advice.
- Support: support@algotraders24.ai
