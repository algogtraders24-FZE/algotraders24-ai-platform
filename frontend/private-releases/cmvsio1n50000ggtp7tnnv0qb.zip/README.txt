XXX BTC v1.02  -  24/7 breakout Expert Advisor for Bitcoin (BTCUSD), MetaTrader 5
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES
  XXXBTC.ex5   the Expert Advisor (the optional AI model is built in - no model files to copy)

LICENCE KEY (required)
  Your key is on your AT24 purchase page (Dashboard > Purchases > this product > "Your licence key").
  1. MetaTrader 5: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add
        https://www.algotraders24.ai
  2. Attach the EA to a BTCUSD M15 chart, Allow Algo Trading, paste the key into InpLicenseKey.
  One key works on ONE trading account at a time and only for this product. To move it: Dashboard > Purchases > this
  product > "Change trading account" (2 changes per 30 days). The EA checks the key at start and every 4 hours; if it is
  revoked or used on another account it stops opening NEW trades (open trades are still managed). A short internet
  outage never stops a running EA (72 hours of grace). The Strategy Tester needs no key.

WHAT IS NEW IN v1.02
  * A new chart dashboard: status chip (entries on / off and the reason), account, drawdown, spread, performance, module
    switches, shields and limits, open positions and the last 5 closed trades. Pause and Close-All buttons below it.
  * The profit factor on the panel is now gross profit / gross loss (the old panel divided the net profit by the number of
    losing trades, which was wrong).
  * The trading logic is unchanged from v1.01. The dashboard is never drawn in the Strategy Tester unless you switch
    InpDashInTester on and use visual mode.

READ THIS
  * The marketplace evidence belongs to the tested configuration of this product. Use the settings file of the listing to
    reproduce it. Start on a DEMO account with a small lot. Past performance is not a guarantee of future results.
    Trading leveraged products is risky; this is not financial advice.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
