AT24 PIVOT LEVELS MAP - TradingView version v1.00 (Pine Script v6)

WHAT IT SHOWS
- Daily and weekly pivot levels (P, R1, R2, S1, S2); monthly pivots, R3/S3 and Camarilla H3/H4/L3/L4 can be switched on.
- The daily CPR (top and bottom) and its width compared with the last 20 days: NARROW, WIDE or normal - versus the average only, never a forecast.
- A dashboard with where price is now (above, inside or below the CPR), the nearest level above and below with the distance, and a table of every level with the nearest one highlighted.
- Levels come from the previous completed day, week and month of the chart's exchange.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol; works on any timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_PivotLevelsMap.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The AT24 dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account (Scripts > your scripts).

THINGS TO KNOW
- It is plain Pine Script v6 source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to the buyer's AT24 account. Personal use on your own TradingView account, please do not publish or share the file.
- Limits: no logo image inside the dashboard (TradingView tables cannot show images); the weekly numbers were compared with our MT5 version on XAUUSD and matched within the difference between two data feeds.
- Education tool, not a signal. Nothing here is investment advice and nothing predicts future price.
- Support: support@algotraders24.ai
