AT24 REGIME PULSE - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (one dashboard + one sub-window)
- Regime label: TREND, STRONG TREND, RANGE, CHOP (volatile range), QUIET or MIXED, colour-coded in a histogram.
- Trend quality: Kaufman Efficiency Ratio (net move divided by the path travelled, 0 to 1).
- Volatility rank: where today's ATR sits versus the last 500 bars (0 to 100).
- Spread / ATR cost ratio with a HIGH COST warning, and the trading session (GMT): Asia, London, London-New York overlap, New York, Rollover.
- Optional alert when the regime changes (at bar close only, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Regime Pulse indicator (the indicator is built into the EA file, nothing else to install) in its own window below the chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_RegimePulse_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_RegimePulse_Licensed from Navigator > Expert Advisors onto a chart (best on M5-H1 of any symbol). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The indicator window opens below the chart; the dashboard appears top-left. To change measurement settings, open the indicator's own properties from the chart's indicator list.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The calculation matches an independent Python recomputation on 4,000 real XAUUSD M5 bars (differences only from rounding). Closed bars never repaint.
- It describes the CURRENT state. In our own check the regimes did NOT persist: the Efficiency Ratio of the next 20 bars was about 0.21-0.24 in every regime (XAUUSD M5, 2025-26). It does not predict anything.
- XAUUSD M5 fact from the same data: spread cost was about 6% of ATR in strong-trend bars and about 13% in QUIET bars.
- Not tested: live-money use, alerts on a live feed, other symbols and brokers.

IMPORTANT
- Context tool. Not a signal. Past conditions do not predict future results. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
