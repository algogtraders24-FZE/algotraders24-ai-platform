AT24 MARKET STRUCTURE - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- BOS (break of structure, with the trend) and CHoCH (change of character, against it) lines on your chart, plus the open swing high and low as dashed lines.
- One fixed rule: swings are confirmed after N bars (default 5), a break needs a bar CLOSE beyond the latest unbroken swing. Closed bars only.
- A dashboard: structure state, last break, counts, and how often price was still going in the break direction 20 bars later after a BOS, after a CHoCH, and after any bar.
- Alert conditions for a BOS and for a CHoCH.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Market_Structure.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 261 BOS and 252 CHoCH: 20 bars later price was still going in the break direction after 55% of BOS and 44% of CHoCH, 54% after any bar). The MetaTrader 5 test on M15 showed the reverse, so there is no consistent difference. Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
