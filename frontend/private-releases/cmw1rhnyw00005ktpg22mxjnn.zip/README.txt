AT24 NY OPENING RANGE - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- The 09:30-10:00 New York opening range drawn as a box on the right broker-clock hour all year (daylight-saving aware, checked against the standard time-zone database), coloured by outcome: not broken yet, broke up, broke down, no break.
- A dashboard with the state (opens in n minutes, forming, set, broken), the New York time now and the detected clock rule.
- Statistics on YOUR symbol and broker data: how often the range broke up, down or not at all, how often the break was still beyond the range at 16:00, how often it ran one box height, and how often a break closed back inside within 4 bars.
- A control window at 11:00 (same length) so you can see whether the opening range behaves any differently from an ordinary window.
- Optional alert when today's range breaks (bar close, no repaint). M30 or lower charts only.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the NY Opening Range indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_NyOr_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_NyOr_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The broker-to-New-York time conversion equals the standard time-zone database on all 8,000 bars, and the ranges, breaks and statistics match an independent Python calculation (all 106 days identical).
- Real result on one broker feed: XAUUSD M15, last 87 complete days, 09:30-10:00 New York range: it broke up about 43% of days and down about 57%; the break was still beyond the range at 16:00 on about 54% of days; about 56% of breaks closed back inside within 4 bars; about 51% ran one box height. The 11:00-11:30 control window gave: held about 60%, fell back about 60%, ran about 52%. The opening range behaves like any other 30-minute window: a coin flip on direction, no edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
