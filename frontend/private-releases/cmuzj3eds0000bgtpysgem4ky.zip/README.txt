XXX US30 v1.01  -  Multi-module breakout EA for the Dow Jones (US30), M15
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES IN THIS DOWNLOAD
  XXXUS30.ex5                    the Expert Advisor (the optional AI model is built in - no model files to copy)
  XXXUS30_tested_settings.set    the EXACT inputs of the backtest the marketplace evidence is based on
                                 (AI filter OFF - see below)

INSTALL (3 minutes)
 1. MetaTrader 5: File > Open Data Folder > MQL5 > Experts: copy XXXUS30.ex5 there (refresh the Navigator).
 2. Open a US30 chart on M15 and drag XXXUS30 onto it. Allow Algo Trading.
 3. Inputs tab > Load > XXXUS30_tested_settings.set to reproduce the tested configuration, then set InpFixedLot
    to a size that is right for your account (see below).

IMPORTANT - READ BEFORE USING
 * THE AI FILTER: the EA can score every setup with a small neural network (InpUseONNX). The model is built into
   the EA. The backtest the marketplace evidence is based on was run WITHOUT the AI filter (the tester could not
   load the model file), so the tested-settings file has InpUseONNX=false. The EA's built-in default is true.
   With it on the EA trades far less; that mode has not been backtested. Use the .set file to get the tested
   behaviour. The model was trained by the seller on the most recent 30,000 M15 bars at training time
   (5 Jun 2025 - 11 Sep 2026), so it has seen the period the backtest covers.
 * LOT SIZE: the backtest used a FIXED 1.0 lot on a 10,000 deposit. The EA's default is 0.01. Results scale with
   lot size and so does the risk. Note: US30 on Exness has a 0.05 minimum lot - adjust to your broker.
 * POINTS ARE BROKER POINTS: stop loss, take profit, breakeven, trailing and spread limits are in the symbol's
   POINTS. On Exness US30 (digits 1, point 0.1) 120 points = 12.0 index points. On a broker whose US30 has
   0 digits (point 1.0) the same numbers mean 120 index points - 10x wider. Re-scale before trading.
 * SYMBOL: tested on Exness "US30". Other brokers name it DJ30 / WS30 / US30.cash etc.
 * PENDING-ORDER BREAKOUT EA: BUY STOP / SELL STOP orders for up to 5 modules (Nova, Apex, Zenith, Pulse,
   Eclipse) at the same time; the tested run reached 11 simultaneous positions. Broker minimum stop distance,
   spread and slippage can change results materially.
 * Start on a DEMO account. Past performance is not a guarantee of future results. Trading leveraged
   products is risky; this is not financial advice.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
