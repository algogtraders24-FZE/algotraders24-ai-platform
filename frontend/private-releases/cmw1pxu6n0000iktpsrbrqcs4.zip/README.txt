AT24 MARKET STRUCTURE - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- BOS (break of structure, with the trend) and CHoCH (change of character, against it) lines drawn on your main chart, plus the open swing high and swing low levels.
- One fixed rule: swings are confirmed after N bars (default 5), a break needs a bar CLOSE beyond the latest unbroken swing, a break with the current structure is BOS, the first one against it is CHoCH. Closed bars only, so nothing repaints.
- A dashboard with the structure state (up / down), the last break and how long ago it happened.
- Statistics on YOUR symbol and broker data: how many BOS and CHoCH happened and how often price was still in the break direction 20 bars later, against an ordinary bar.
- Optional alert on a new break (bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Market Structure indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_MarketStructure_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_MarketStructure_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The breaks and statistics match an independent Python calculation (all 364 events identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, last 8,000 closed bars, about 370 breaks: 20 bars after a BOS price was still going in the break direction about 43% of the time, after a CHoCH about 55%, against about 48% after an ordinary bar. Structure labels describe, they do not predict: no better than any other bar. Descriptive only, NOT an edge. Other swing sizes give other events.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
