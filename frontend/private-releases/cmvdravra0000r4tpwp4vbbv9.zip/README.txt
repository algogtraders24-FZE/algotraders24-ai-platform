QuantumTech NAS v1.07
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES IN THIS DOWNLOAD
  QUANTUMTECH_NAS.ex5     the Expert Advisor

LICENCE KEY (required since v1.07)
  Your key is on your AT24 purchase page (Dashboard > Purchases > this product > "Your licence key").
  1. MetaTrader 5: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add
        https://www.algotraders24.ai
  2. Attach the EA, open the Inputs tab and paste the key into  InpLicenseKey.
  One key works on ONE trading account at a time (and only for this product). Moving to another broker/account or VPS:
  Dashboard > Purchases > this product > "Change trading account" (2 changes per 30 days), then run the EA there.
  The EA checks the key when it starts and every 4 hours. If the key is revoked, belongs to another product or is
  used on another account, the EA stops opening NEW trades; trades that are already open are still managed.
  A short internet outage never stops a running EA (72 hours of grace).
  The Strategy Tester needs no key, so you can still backtest the EA.
  (Older versions used a separate account + expiry key from the seller; that key is no longer used.)

INSTALL (3 minutes)
 1. MetaTrader 5: File > Open Data Folder > MQL5 > Experts: copy QUANTUMTECH_NAS.ex5 there (refresh the Navigator).
 2. Open a chart of the index symbol it is made for (see the listing) and drag QUANTUMTECH_NAS onto it. Allow Algo Trading.
 3. Inputs tab > paste your licence key into InpLicenseKey, then set the lot size / risk that is right for your account.

IMPORTANT - READ BEFORE USING
 * Start on a DEMO account. Past performance is not a guarantee of future results. Trading leveraged
   products is risky; this is not financial advice.
 * Broker, symbol names, spread and execution differ between brokers and change results. Check the symbol and the
   point-based inputs on your own broker before trading.
 * Everything the marketplace shows about this product is described on its listing page.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
