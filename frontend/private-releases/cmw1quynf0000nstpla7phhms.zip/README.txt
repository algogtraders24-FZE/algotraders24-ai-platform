AT24 FVG ZONES - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- Every three-bar fair value gap on closed bars (bullish if the low of the third bar is above the high of the first, bearish the other way), filtered by size in ATR, drawn as zones; only gaps not yet filled are drawn, touched ones are labelled.
- A dashboard: number of open gaps, the nearest open gap above and below price, how many gaps were measured, how often price came back into a gap within 50 bars (and the median wait), how often it filled it completely, and the same measure for a control level at the same distance from another bar's close.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_FVG_Zones.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history. The statistics are calculated when the script runs on the last bar, so on very long histories it can take a moment.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 1,070 gaps: revisited within 50 bars 87% with a median of 2 bars, filled completely 75%, control level 89%). Not tested: live-money use. Descriptive history; it shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
