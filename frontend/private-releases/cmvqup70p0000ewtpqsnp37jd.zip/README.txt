XXX US30 v1.14  -  Breakout EA for the Dow Jones (US30), M15
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES
  XXXUS30.ex5   the Expert Advisor (the optional AI filter model is built in - no model files to copy)

LICENCE KEY
  Your key is on your AT24 purchase page (Dashboard > Purchases > this product > "Your licence key").
  1. MetaTrader 5: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add  https://www.algotraders24.ai
  2. Attach the EA to a US30 M15 chart, Allow Algo Trading, paste the key into InpLicenseKey.
  One key works on ONE trading account at a time and only for this product. To move it: Dashboard > Purchases > this product >
  "Change trading account". The EA checks the key at start and every 4 hours; if it is revoked or used elsewhere it stops opening NEW
  trades (open trades are still managed). A short internet outage never stops a running EA. The Strategy Tester needs no key.

WHAT CHANGED IN v1.14
  Three modules (Nova, Apex, Zenith), exactly one order or position per module, new dashboard panel, AI model works in the
  Strategy Tester too. The earlier Pulse and Eclipse modules were removed.

READ THIS
 * v1.14 has NOT been validated by the marketplace evidence. The evidence shown on the listing belongs to the earlier v1.03 build
   (5 modules). The seller's own real-tick tests of the 3-module logic were not profitable; use a DEMO account first.
 * Defaults: fixed lot 0.01, stop 1200 / target 4000 points, M15. Points are broker points - check your broker's US30 digits.
 * Past performance is not a guarantee of future results. Trading leveraged products is risky; this is not financial advice.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
