AT24 ANCHORED VWAP - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- Day, week (Monday) and month volume-weighted average price (VWAP) lines on your chart, with the day VWAP's +-1 and +-2 standard-deviation bands. The VWAP is built from the broker's TICK volume.
- A dashboard: whether price is above or below the day VWAP and by how many standard deviations, and the same distance for the week and the month VWAP.
- A test on YOUR symbol and broker data (last 8,000 bars): after the first close 2 standard deviations from the day VWAP, how often price traded back to the VWAP before the day ended, how often it went on to 3 standard deviations, how often neither, and how often closes were above the day VWAP - with the random-walk yardstick printed next to it.
- Anchors are in GMT using a daylight-saving aware broker clock that falls back to a fixed offset (and says so) when it cannot be detected.
- Statistics use closed bars only; the VWAP lines include the forming bar.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Anchored VWAP indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_AnchoredVwap_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_AnchoredVwap_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The day, week and month VWAP and standard deviations match an independent Python calculation (max difference about 5e-6 for the VWAP and 6e-5 for the SD, which is CSV rounding), and the reversion test is identical (86 events, 66 reverted, 12 extended, 8 neither with the daylight-saving aware clock).
- Real result on one broker feed: XAUUSD M15, last 8,000 bars (84 days measured), tick volume: after the first close 2 standard deviations from the day VWAP, price traded back to the VWAP before the day ended on about 77% of days, went on to a 3 SD close on about 15% and neither on about 7%; about 48% of closes were above the day VWAP. A random-walk yardstick for those barriers is about 33%, but the VWAP itself drifts toward price during the day, which makes touching it easier - so this is NOT an edge: a touch is not a profit, stretches can run first and costs are ignored. Another broker feed gave 77 / 14 / 9% over 86 days. Descriptive only.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
