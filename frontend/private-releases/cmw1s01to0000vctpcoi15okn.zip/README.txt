AT24 NEWS RISK CLOCK - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- A countdown to the next high-impact events from MetaTrader's own built-in economic calendar (USD by default, any currencies you list), with vertical event lines on the chart.
- A risk-window state: CLEAR / NEWS SOON / RISK WINDOW / JUST RELEASED.
- Statistics on YOUR symbol and broker data: how big the price range was in the 30 minutes after such news compared with the same clock time on quiet days (no other event within +-60 minutes), how often it was at least 1.5x and 2x bigger, and how often it was quieter than a normal quiet-day window.
- It measures the SIZE of the move, not its direction.
- It needs a live, connected terminal: the economic calendar does not exist in the Strategy Tester (the dashboard says so). Calendar data come from MetaQuotes through your terminal and can be late or revised: check important events yourself.
- Event times use the chart's broker clock; if your terminal is not connected to the broker, set the input "Clock of the calendar times" to match.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the News Risk Clock indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_NewsClock_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_NewsClock_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The per-event ratios and every statistic match an independent Python calculation (all 159 events identical on 8,000 bars).
- Real result on one broker feed: It depends on the broker feed. On our IC Markets demo feed (XAUUSD M15, last 85 days, 163 high-impact USD events) the typical event gave about 0.98x the quiet-day range at the same clock time (median 11.65 vs 9.82), at least 1.5x in about 23% of events, at least 2x in about 10%, and 55% were quieter than a normal quiet-day window. On another broker feed (Equiti, 159 events) the same measure gave a median of about 1.41x, 47% at least 1.5x, 34% at least 2x and 24% quieter. So the news effect on gold range was not consistent between feeds. Descriptive only: it is the size of the move, not its direction, and not an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
