AT24 PROP GUARDIAN - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- You enter your daily loss limit in percent, a maximum total loss in percent and an optional daily profit lock.
- When 90% of a loss limit (adjustable buffer for slippage) is used, it closes every managed position, deletes pending orders and blocks new ones until the next daily reset (daily and profit locks) or until you press UNLOCK (maximum-loss lock). It tells you when it locks (alert, optional push, log, dashboard).
- A runaway alert when another EA keeps re-opening trades while the account is locked (a number of blocked trades you choose); the closing continues by default.
- Optional magic-number filter, a day definition you choose (broker reset hour, balance or equity basis) and a dashboard with an UNLOCK button.
- It places NO trades of its own and works with any EA or manual trading on the account. It must run 24/5 (a VPS is recommended). It cannot switch another EA off or disable AutoTrading; it can only close trades and alert.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Prop Guardian indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_PropGuardian_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_PropGuardian_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- A Strategy Tester self-test on the licensed build (XAUUSD M5, 2026-10-26 to 2026-10-30, 10,000 USD, a test EA opening 1 lot every 10 minutes even while locked): it locked once when 94% of the max-loss limit was used, blocked 522 of 523 new trades, left 0 positions open and raised the runaway alert once.
- Real result on one broker feed: This is a protection tool, not a strategy: it has no trading results. In the Strategy Tester self-test (a test EA opening 1 lot every 10 minutes even while the account was locked, daily limit 5%, max loss 10%, act at 90%) it locked once at 94% of the max-loss limit, closed the 522 trades that were re-opened while locked, left 0 positions open and raised the runaway alert once. The previous build's runs also showed the daily lock unlocking at the next daily reset.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
