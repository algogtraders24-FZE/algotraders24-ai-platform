AT24 SQUEEZE METER - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (a sub-window under your chart + one dashboard)
- A Bollinger-inside-Keltner squeeze detector: grey/red dots on the zero line (red = squeeze on) and a momentum histogram (lighter = momentum rising, darker = fading).
- State: SQUEEZE ON (how many bars), RELEASED n bars ago, or NO SQUEEZE; momentum direction and the band ratio (BB/KC).
- Statistics on YOUR symbol and broker data: how many squeezes of at least 6 bars happened in the last 8,000 bars, the median squeeze length, the range of the next 20 bars after a release (in ATR) against the range after any bar, how often it was wider than usual, and how often the momentum sign matched the bigger side.
- Optional alert when a squeeze releases (bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Squeeze Meter indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SqueezeMeter_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SqueezeMeter_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The maths match an independent Python calculation (squeeze state and momentum; 137 releases identical).
- Real result on one broker feed (XAUUSD M15, last 8,000 closed bars, 132 squeezes of 6+ bars): the 20 bars after a release had a median range of about 4.5 ATR against about 4.6 ATR after any bar; wider than usual after about 46% of releases; the momentum sign matched the bigger side about 52% of the time (a coin flip). On this data a squeeze did NOT precede a bigger move. That is descriptive and NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
