AT24 ROUND LEVELS - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- A grid of round-number levels at three steps you choose (10, 50 and 100 by default, suited to gold) drawn across your chart, with the nearest big level and its distance.
- Statistics on the bars loaded on your chart: for each step, how many times price touched a level, how often it bounced (moved 1 ATR away before moving 1 ATR through the level, within 20 bars) and how often it broke through - each next to the same measure on control levels half a step away. Equal numbers mean no round-number effect.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Round_Levels.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h: 6,220 / 1,321 / 661 touches at the 10 / 50 / 100 steps; bounce 51% / 47% / 48% against about 51% / 51% / 47% at control levels; break-through 48% / 51% / 50%). A first run exposed a loop-direction bug that counted levels the bar had not touched; it was fixed and re-tested. Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
