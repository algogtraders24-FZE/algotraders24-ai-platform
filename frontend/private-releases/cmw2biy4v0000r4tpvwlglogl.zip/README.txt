AT24 POSITION SIZE - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- You set the risk (percent of your live balance or of an account size you choose) and a stop distance (fixed price units or an ATR multiple); it shows the lot size rounded DOWN to the symbol's real volume step and limits.
- The loss per 1.00 lot at the stop, the actual money and percent at risk with that lot, the margin needed (when an account is connected), and targets in R.
- A ladder of stop and target levels drawn around the last close.
- It works for gold, forex and indices because it uses the platform's own tick size and tick value; if the platform gives no tick value (no account connected) it estimates it and says so in orange.
- A minimum lot that would risk more than the money available gives a clear warning and 0 lots instead of a hidden oversize.
- It is a calculator: it never places, modifies or closes a trade.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Position Size indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_PositionSize_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_PositionSize_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The formula matches an independent exact-decimal calculation on 10 test cases and the real gold symbol (all identical), and the platform's own OrderCalcProfit on a connected demo account (XAUUSD 0.16 lot with a 12.50 stop: -200.00; EURUSD 0.10 lot with a 20 pip stop: -20.00) equals the formula's loss exactly.
- Real result on one broker feed: This is a calculator, not a strategy: it has no trading results. Example on a demo account: 1% risk with a 10.00 stop on gold gave 0.02 lots, with an actual risk of 0.97% after rounding the lot down. Spread, slippage and gaps can make a real loss larger than the calculated stop loss.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
