AT24 EXPECTED RANGE - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The usual daily range (mean of the previous 14 complete days, no look-ahead), today's range so far and the percentage used, with a state: QUIET / NORMAL / STRETCHED / EXTREME.
- Today's open and the projected day high (today's low + the usual range) and low (today's high - the usual range) drawn on your chart.
- Statistics on the days loaded on your chart: the median day, how often days went past 100% and 150%, how often a day that reached 100% finished at 125% or more, and how often the close moved at least half the day's range from the open.
- Days follow the chart symbol's exchange day. Use an H4 or lower chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, H4 or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Expected_Range.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 459 complete days: median day 95% of the usual range, 45% of days over 100%, 12% over 150%; of the 207 days that reached 100%, 53% ended at 125% or more). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
