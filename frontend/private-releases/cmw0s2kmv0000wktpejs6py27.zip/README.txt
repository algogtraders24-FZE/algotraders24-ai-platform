AT24 LIQUIDITY LEVELS - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (six level lines on your chart + one dashboard)
- The previous day, week and month high and low (PDH, PDL, PWH, PWL, PMH, PML) as rays with a live state label: untouched, swept (price traded beyond) or accepted (a bar closed beyond).
- The distance from price to each level.
- Statistics from the last 60 days on YOUR symbol and broker data: how often the previous-day high and low were swept, and after a sweep how often the day closed back inside versus accepted beyond.
- Optional alert when a day level is swept (at bar close, no repaint). Day boundaries are GMT with an automatic broker-clock offset.
It never prints buy or sell arrows.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Liquidity Levels indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_LiquidityLevels_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_LiquidityLevels_Licensed from Navigator > Expert Advisors onto a chart (M5 to H4, any symbol). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. To change settings, open the indicator properties from the chart indicator list.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The maths match an independent Python calculation (89 day, week and month periods compared, 0 mismatches; the test also caught and fixed a window-boundary bug).
- Real result on one broker feed (XAUUSD M15, last 60 GMT days, 53 days with a previous-day level): the previous-day high was swept about 41-42% of the time, the low about 57%, either about 77%, both about 21%. After a sweep the day closed back inside about 58-60% and accepted beyond about 40-42%, but that is only 52 sweeps, so the uncertainty is wide. It is descriptive and NOT an edge: our earlier scan of 25 entry rules, which included a previous-day sweep rule, found no cost-adjusted edge.
- Not tested: live-money use, alerts and live ticking of the states beyond a screenshot. The server-to-GMT conversion uses the current offset, so days from the other side of a daylight-saving change can be one hour off.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
