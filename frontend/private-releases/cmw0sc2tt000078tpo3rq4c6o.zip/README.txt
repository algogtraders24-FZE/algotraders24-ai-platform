AT24 TREND PULLBACK MAP - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (EMA ribbon on your chart + one dashboard)
- An EMA 20 / 50 / 200 ribbon (periods are inputs) with the mid EMA coloured by trend: up, down or range.
- Where price is now: running, extended from the fast EMA (in ATR), in the pullback zone, deeper than the zone, or trend broken.
- Small triangles that mark where price touched the fast EMA inside a trend. They are NOT buy or sell arrows.
- Statistics on YOUR symbol and broker data: how often a pullback to the fast EMA resumed the trend versus failed, the median depth in ATR and how many bars it took.
- Optional alert on a new touch (at bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Trend Pullback Map indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_TrendPullback_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_TrendPullback_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. To change the EA periods or statistics windows, open the indicator properties from the chart indicator list.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The maths match an independent Python calculation (EMA and ATR to 5e-6, trend state 0 mismatches over 8,000 bars, all 438 pullback events identical).
- Real result on one broker feed (XAUUSD M15, last 8,000 closed bars, a few hundred resolved touches of the 20 EMA inside a 20/50/200 trend): the trend resumed (a new 20-bar extreme before a close past the 50 EMA, within 20 bars) about 39% of the time and failed (a close past the 50 EMA first) about 55%; the rest resolved neither way. Median depth about 3 ATR, median 4 bars to resolve. On this data a plain EMA pullback failed more often than it resumed. That is descriptive, depends on the definitions shown on the dashboard, and is NOT an edge: our earlier scan of 25 entry rules found no cost-adjusted edge for EMA pullbacks.
- Not tested: live-money use, alerts beyond a screenshot. The dashboard zone state uses the last closed bar.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
