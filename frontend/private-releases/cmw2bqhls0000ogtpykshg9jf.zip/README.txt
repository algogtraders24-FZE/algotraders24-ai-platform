AT24 PROP GUARDIAN - MetaTrader 5 version v1.01 (licensed Expert Advisor, protection tool)

WHAT IT DOES
- You set your own daily loss limit (%), a maximum total loss (%) and an optional daily profit lock.
- When 90% of a loss limit (adjustable buffer for slippage) is used, it CLOSES every managed position, DELETES pending orders and BLOCKS new trades until the next daily reset (daily and profit locks) or until you press UNLOCK (maximum-loss lock). It tells you when it locks (alert, optional push, log, dashboard).
- A runaway alert when another EA keeps re-opening trades while the account is locked.
- It places NO trades of its own and works with any EA or manual trading on the account. It cannot switch another EA off or disable AutoTrading; it can only close trades and alert.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_PropGuardian_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_PropGuardian_Licensed onto ONE chart of the account you want to protect (any symbol). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product) and set your limits.
5. Keep Algo Trading switched on and keep the terminal running 24/5 (a VPS is recommended). If the EA is stopped, nothing is protected.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours). IF THE LICENCE IS INVALID THE GUARDIAN IS OFF AND PROTECTS NOTHING - the EA says so on the chart.
- The Strategy Tester needs no key.

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings in the real MetaEditor.
- Strategy Tester self-test on the licensed build (XAUUSD M5, 2026-10-26 to 2026-10-30, 10,000 USD, a test EA opening 1 lot every 10 minutes even while locked; daily limit 5%, max loss 10%, act at 90%): it locked once at 94% of the max-loss limit, closed the 522 trades re-opened while locked, left 0 positions open and raised the runaway alert once. In an earlier run with only the daily lock it unlocked at the next daily reset.
- Not tested: a live account, alerts and push beyond log lines, the licence check with a real purchase.

IMPORTANT
- Protection tool, not a guarantee: gaps, slippage, a stopped EA or a stopped VPS can still cause losses beyond a limit. It cannot prevent a breach and does not make you pass any challenge.
- Rules differ by firm: set your own limits and reset hour. Not affiliated with any prop firm. A position carried across the daily reset counts against the NEW day's limit.
- Do not attach it to an account where you do not want trades closed: it closes ALL positions (or one magic number, if you set it) when a limit is reached.
- Not financial advice. Support: support@algotraders24.ai
