AT24 DRAWDOWN & RECOVERY - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- It reads your account's closed-deal history, rebuilds the performance curve and shows the current drawdown below the peak (with floating profit and loss), the worst drawdown on record and the gain needed to get back to the peak (a 50% loss needs +100%).
- A recovery table (10 / 20 / 30 / 50 / 75 / 90% drawdowns and the gain each needs) and a losing-streak table for your own risk per trade: how much 5, 10 and 20 losses in a row cost and how many losses in a row it takes to reach -10% and -20%.
- An optional magic-number filter to look at one strategy's results on top of the account.
- With no account connected it shows only the formula tables and says so. Deposits and withdrawals are assumed to have been made at the start.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Drawdown & Recovery indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_DrawdownRec_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_DrawdownRec_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The recovery table, the losing-streak table and three synthetic equity curves match an independent calculation (all identical), and on a real demo account history of 269 deals the numbers on screen match hand arithmetic.
- Real result on one broker feed: This is a tracker and a calculator, not a strategy: it has no trading results. On a real demo account history (269 closed deals) it showed the account 60.2% below its peak and +151.1% needed to get back (1 / 0.398 - 1 = 1.511), and a worst drawdown on record of 75.3% that needed +304.5%. The recovery maths is exact arithmetic: a 50% loss needs +100%, a 75% loss +300%.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
