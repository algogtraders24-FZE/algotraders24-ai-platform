AT24 CURRENCY STRENGTH METER - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Currency Strength Meter shows how strong or weak each of the eight major currencies is, measured from the 28 major pairs on your chart timeframe.

What it does

- Draws one line for each of EUR, USD, GBP, JPY, CHF, AUD, CAD and NZD in a separate window. A line above zero means the currency gained against the others over the measuring period, below zero means it lost.

- Ranking panel: the eight currencies from strongest to weakest, with the value, and a mark when the rank moved up or down compared with a number of bars ago.

- Widest gap: shows the strongest and the weakest currency and how far apart they are.

- Each currency is the average move of all pairs that contain it, so a move in one pair does not decide the result.

- Works on any chart and timeframe. The measuring period is a number of bars of the chart timeframe, and the lines can be smoothed.

- Reads broker prefix and suffix from the chart symbol, or you can enter them. Pairs your broker does not offer are skipped and the panel shows how many of the 28 pairs were used.

- Optional alert and push message when the strongest or weakest currency changes. They are off by default.

Points to know

- The values describe what already happened. They are not a signal and not a forecast, and a strong currency against a weak one does not mean a trade will work.

- The newest bar updates while it forms. Closed bars keep their values.

- Add the major pairs to Market Watch so the history is available. The first calculation can take a moment while the history of 28 symbols loads.

- The panel is hidden in the Strategy Tester by default.

Inputs

Measuring bars, smoothing, history bars, rank comparison bars, broker prefix and suffix, alerts, panel and its position.

Descriptive history on your broker data. Context tool, not a signal or a forecast. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_CSM_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_CSM_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
