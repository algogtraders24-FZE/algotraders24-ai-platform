AT24 LOCAL TRADE COPIER  -  MT5 to MT5  -  v1.1.0
=================================================================
Copies the open positions of one MetaTrader 5 account to another
MetaTrader 5 account on the SAME computer (or the same VPS).
No server, no DLL and no account password: the two terminals exchange a small text file in the shared
"Common\Files" folder (MT4 and MT5 both use it, so both terminals must run
under the same Windows user), so trade data never leaves your computer.
The Receiver contacts algotraders24.ai only to check your licence key (see LICENCE KEY below).

WHAT YOU GET
  AT24_Copier_Master_MT5.ex5      - attach in the MT5 terminal you want to COPY FROM
  AT24_Copier_Receiver_MT5.ex5    - attach in the MT5 terminal you want to COPY TO

LICENCE KEY (required since v1.1.0)
  The RECEIVER needs your AT24 licence key (the Master needs none). Your key is on your AT24 purchase page
  (Dashboard > Purchases > this product > "Your licence key").
  1. In the DESTINATION terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL"
     and add   https://www.algotraders24.ai
  2. When you attach the Receiver, paste the key into the input  InpLicenseKey.
  One key = ONE receiving (destination) account. Moving to another account/broker/VPS: Dashboard > Purchases >
  this product > "Change trading account" (2 changes per 30 days), then run the Receiver there.
  The Receiver checks the key when it starts and every 4 hours. Revoked key / other product / other account:
  it stops opening NEW copies (copies that are already open still follow the Master's closes and SL/TP).
  A short internet outage never stops a running Receiver (72 hours of grace).
  The only data sent to algotraders24.ai is the key and the destination account number + server name.

SET UP (about 3 minutes)
 1. Copy AT24_Copier_Master_MT5.ex5 into the MQL5\Experts folder of the SOURCE terminal and
    AT24_Copier_Receiver_MT5.ex5 into the MQL5\Experts folder of the DESTINATION terminal
    (File > Open Data Folder > MQL5/MQL5 > Experts), restart or refresh.
 2. SOURCE terminal: drag "AT24_Copier_Master_MT5" onto any chart.
    Set ChannelId (e.g. "gold1"). The Master only READS positions - it never
    sends an order.
 3. DESTINATION terminal: drag "AT24_Copier_Receiver_MT5" onto any chart.
    Set the SAME ChannelId. Allow trading: the AutoTrading / Algo Trading
    toolbar button and "Allow live trading" / "Allow Algo Trading" in the EA
    properties.
 4. The chart comment shows the live status: master found / offline, copies
    opened, closed, SL/TP updates, skipped, errors.
 5. START ON A DEMO ACCOUNT FIRST and use the Receiver's DryRun option to see
    what it would do before it sends any order.
 Only ONE Receiver may run per channel in a terminal: a second one detects the
 first and does nothing (otherwise every trade would be copied twice).

THE DESTINATION ACCOUNT MUST BE A HEDGING ACCOUNT. On a netting account the
Receiver refuses to trade (DryRun still works). The Master only reads the source
account; a netting SOURCE account has not been tested.

WHAT IS COPIED
  - new market positions (buy/sell, symbol, volume scaled to your settings)
  - stop loss / take profit, and every later change of them
  - partial closes and added volume
  - closes
Each copy carries its own magic number (ReceiverMagic, default 8240124 - change it
if another EA of yours already uses that number) and the comment
"AT24C:<master position id>"; positions you open by hand or with other EAs are
never touched.

NOT COPIED (v1.1.0)
  - pending orders (limit/stop) - only filled positions are copied
  - trailing stops are followed only through the SL values the master reports
  - the master's comments and magic numbers

MAIN SETTINGS (Receiver)
  LotMode          Multiplier / Fixed lot / Equity ratio (my equity / master equity)
  LotMultiplier    scales the master lot (also scales Equity ratio)
  MaxLotPerTrade   hard cap per copied trade (default 10)
  ReverseCopy      copy buys as sells and the other way round (SL/TP are swapped)
  CopySLTP         copy and follow stop loss / take profit
  CopyExistingOnStart  default OFF: positions already open when the Receiver
                   starts are NOT copied
  MaxEntryDelaySec a trade the master opened longer ago than this is not copied
  MasterSymbolPrefix / MasterSymbolSuffix   what the MASTER broker adds to symbol names
                   (stripped before mapping), e.g. prefix "m." or suffix ".m"
  ReceiverSymbolPrefix / ReceiverSymbolSuffix   what YOUR broker adds, e.g. "#" or "+"
  SymbolMap        explicit pairs that win over the rules above,
                   e.g. XAUUSD=GOLD;US30=DJ30
                   Example: master "m.EURUSD.sd" -> prefix "m." + suffix ".sd" are
                   stripped, then your own prefix/suffix are added.
  AllowedSymbols, MasterMagicFilter   copy only what you want
  StopsPolicy      what to do when your broker's minimum stop distance rejects
                   the master's SL/TP: SKIP the trade (default) or CLAMP
  MaxSpreadPoints, MaxSlippagePoints, DryRun, ExpectedMasterLogin

BUILT-IN SAFETY
  - A Master that is silent for more than StaleSeconds is treated as OFFLINE and
    the Receiver does NOTHING (it never closes positions because a file is old).
  - A partially written file is detected by a checksum and ignored.
  - If the master book becomes empty, copies are closed only after
    EmptySnapshotConfirmSec of continuous emptiness (guards against a terminal
    restart publishing an empty book).
  - At most 3 open attempts per master position; an order whose outcome is
    unknown is not blindly re-sent.
  - Copies stay mappable even if the broker rewrites the position comment or
    (MT4) gives a partially closed order a new ticket.
  - One Receiver per channel and terminal (see SET UP).
  - Not usable in the Strategy Tester (it would be meaningless there).

WHAT WAS TESTED (honest scope)
  - Compiles with 0 errors / 0 warnings (MetaEditor).
  - Protocol self-test inside a real MT5 terminal: 47 / 47 checks passed in a real terminal (CRC-32, tamper and
    partial-write detection, symbol prefix/suffix mapping, lot maths...).
  - End-to-end test on a real MT5 HEDGING DEMO account (loopback: Master and
    Receiver on one terminal): open, SL/TP change, partial close, second
    position, close, nothing left behind - 17 / 17 checks passed, in normal AND
    in ReverseCopy mode.
  - Cross-broker test with TWO SEPARATE MT5 terminals: Master on an Equiti demo
    (symbol EURUSD.sd), Receiver on an Exness demo (EURUSD; ".sd" stripped).
    Every step passed: open at half volume, SL/TP change, partial close, second
    position, its close, final close. A position that already existed on the
    receiving account was left untouched. Measured: 0.2 - 0.3 s per action.
  - NOT tested: netting source accounts, live-money accounts, brokers that
    forbid hedging or copying. Test on demo first.

IMPORTANT
  - Trading leveraged products is risky; this tool contains no trading
    strategy and makes no profit claim.
  - Check that your broker allows trade copying and hedging. Copying trades of
    accounts you do not own or manage, or selling signals, can require a
    licence in your country - you are responsible for compliance.
  - Everything stays on your machine: no data is sent to AT24 or anyone else.

AT24 - Algotraders24    https://www.algotraders24.ai
