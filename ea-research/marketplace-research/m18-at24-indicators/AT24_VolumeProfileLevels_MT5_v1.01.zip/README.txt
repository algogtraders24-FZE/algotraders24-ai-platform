AT24 VOLUME PROFILE LEVELS - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- Yesterday's volume profile (per broker server day) built from TICK volume: each bar's volume is spread over the price bins its high-low covers. It draws the point of control (POC), the value area high and low (VAH / VAL, 70% of the volume) and shades the value area across today.
- A state: price inside, above or below yesterday's value area, and its distance from the POC.
- Statistics on YOUR symbol and broker data: how often price touched yesterday's POC, VAH and VAL, and whether it reacted away from the level before breaking it - each against a mirrored control level at the same distance from the open on the other side.
- Honest about its data: tick volume from the broker feed, not exchange volume. H1 or lower charts only.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Volume Profile Levels indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_VolProfile_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_VolProfile_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- All 88 daily profiles (POC, VAH, VAL) and the three level studies match an independent Python calculation (identical).
- Real result on one broker feed: XAUUSD M15, last 87 days, tick volume: yesterday's POC was touched on about 74% of days (mirrored control level about 61%) and price reacted away from it about 49% of the time (+-13; control about 45%); VAH touched about 72% (control 60%), reacted about 59% (control about 60%); VAL touched about 68% (control 61%), reacted about 60% (control about 47%). The levels were touched somewhat more often than control levels, but the reaction rates are within noise of the controls. Descriptive only, NOT an edge. 87 days is a small sample.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
