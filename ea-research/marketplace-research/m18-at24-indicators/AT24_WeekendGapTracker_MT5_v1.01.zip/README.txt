AT24 WEEKEND GAP TRACKER - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- The latest weekend (market-closed) gap: Friday's closing price, the reopening price, the size in points and in ATR, and whether it has been filled yet - drawn as a zone with the Friday-close line while it is open (when it is within the visible chart).
- A dashboard with the latest gap's direction, size, how long ago the market reopened and its fill status.
- Statistics on YOUR symbol and broker data (last 900 days of H1 history): how many gaps were measured, the typical size, how often they were up, and how often they were filled within 1 hour, 4 hours, 1 day and 5 days - against a control level at the same distance on the other side of the reopening price.
- Works on any chart timeframe from the symbol's H1 history; it rebuilds once per hour and retries until the history is available. Optional alert when the gap is filled.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Weekend Gap Tracker indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_WeekendGap_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_WeekendGap_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- All 137 gaps and the fill and control statistics match an independent Python calculation (identical on 20,000 H1 bars).
- Real result on one broker feed: XAUUSD H1, last 900 days, 149 gaps of at least 0.1 ATR (typical size about 0.40 ATR, about 48% up): price came back to Friday's close within 1 / 4 / 24 hours and 5 days in about 57 / 68 / 83 / 90% of cases, while a control level at the same distance on the other side was reached in about 51 / 72 / 86 / 92%. On another broker feed (136 gaps) it was 51 / 66 / 82 / 90% against 54 / 74 / 87 / 92%. A weekend gap fills about as often as any level that near. Descriptive only, NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
