AT24 HOURLY RANGE HEATMAP - TradingView version v1.00 (Pine Script v6)

WHAT IT SHOWS
- The average H1 range for each of the 24 hours of the day as a coloured heatmap, with the current hour marked.
- The 3 busiest and 3 quietest hours, how many times bigger the busiest hour is than the quietest, and this hour's range so far against the usual full hour.
- Hours are shown in the chart exchange's time, UTC, or UTC+5:30 (input).

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol; use a chart timeframe of 1 hour or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_HourlyRangeHeatmap.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The AT24 dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account (Scripts > your scripts).

THINGS TO KNOW
- It is plain Pine Script v6 source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to the buyer's AT24 account. Personal use on your own TradingView account, please do not publish or share the file.
- Limits: it only uses the history your TradingView plan loads on the chart (free plans load fewer bars, so scroll back or use a plan with more history); no logo image inside the dashboard. On XAUUSD the busiest-versus-quietest ratio matched our MT5 version (about 3.1x).
- Education tool, not a signal. Nothing here is investment advice and nothing predicts future price.
- Support: support@algotraders24.ai
