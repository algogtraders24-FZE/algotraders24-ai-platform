AT24 RANGE DETECTOR - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- Sideways ranges detected from fading trend strength (ADX) and drawn as boxes on your chart: the box stays open while the range lasts and is coloured by how it ended (up, down, or still open).
- A dashboard: whether price is in a range now, the box high and low, where price sits in the box, and the current ADX against the thresholds used.
- Statistics on YOUR symbol and broker data (last 8,000 closed bars): how many ranges finished, the median length and height in ATR, how they ended (up / down / strength rising), how often a breakout went the way of the move before the range, and how often a breakout closed back inside the box within 5 bars (false breakouts).
- Closed bars only, no repaint. Optional alerts.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Range Detector indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_RangeDet_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_RangeDet_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The ADX, ATR and all 153 ranges (start, end, high, low, how each ended, prior move, false-breakout flag, height in ATR) match an independent Python calculation (identical), and so do the statistics.
- Real result on one broker feed: XAUUSD M15, last 8,000 closed bars, 155 finished ranges: median range about 17 bars and 2.9 ATR tall; ranges ended up about 48% and down about 52%. A breakout went the way of the move before the range only about 48% of the time (a coin flip) and about 45% of breakouts closed back inside the box within 5 bars (false breakouts). Descriptive only, NOT an edge. Other settings give other ranges and numbers.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
