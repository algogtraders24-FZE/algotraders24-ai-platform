AT24 SETUP PRO - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Two setup types marked on the chart as they form on closed bars, each with entry, stop and target levels drawn BEFORE the trade (nothing repaints).
- A 4-timeframe trend panel (M15, H1, H4, D1) that tells you whether the timeframes agree or are mixed.
- A scorecard per setup type on the symbol's own history: how many setups, the hit rate, the average result in R after cost, and a sign-flip luck test.
- A verdict that only says POSITIVE or NEGATIVE ON THIS HISTORY when the result is beyond luck; otherwise NO EDGE SHOWN, and TOO FEW with under 30 setups.
- Optional alert on a new setup (bar close). It places no orders.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Setup Pro indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SetupPro_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SetupPro_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The scorecard layer matches an independent Python calculation (343 setups and their scores, all identical); the detection parts are the earlier verified Pullback and Squeeze engines.
- Real result on one broker feed: XAUUSD M15 on one broker demo feed, last 8,000 bars: the first setup type had 218 setups, hit rate 32%, average -0.05 R after cost (luck test p 0.70, NO EDGE SHOWN); the second had 115 setups, hit rate 31%, average -0.09 R after cost (p 0.78, NO EDGE SHOWN). On XAUUSD H1 both also showed no edge. Hindsight statistics on past bars only.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
