AT24 AUTO FIB ZONES - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- Fibonacci levels 0 / 23.6 / 38.2 / 50 / 61.8 / 78.6 / 100 % on the last confirmed swing leg with the 38.2-61.8 zone shaded and the leg drawn.
- Swings are found by a fixed rule (strict extreme of N bars on each side, default 5, confirmed N bars later).
- A dashboard: last leg, current pullback depth, legs measured, median pullback, how often pullbacks reached 38.2 / 50 / 61.8 %, how often they went past 100 % and how often the leg's extreme was beaten.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Auto_Fib_Zones.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 1,082 legs: median pullback 95% of the leg, reached 38.2 / 50 / 61.8% in 92 / 84 / 76% of legs, 48% went past 100%, extreme beaten 48%). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
