AT24 EXPECTED RANGE - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- The usual daily range: the mean high-low of the previous 14 complete days (no look-ahead), shown with today's range so far and the percentage used.
- Today's open and the projected day high (today's low + the usual range) and low (today's high - the usual range) drawn on your chart.
- A state by percent of the usual range used: QUIET / NORMAL / STRETCHED / EXTREME.
- Statistics on YOUR symbol and broker data: the median day as a percentage of the usual range, how often days went past 100% and 150%, and how often a day that reached 100% finished at 125% or more.
- Optional alert when today's range reaches 100% of expected (bar close, no repaint).
- Days are server-time (broker) days built from the chart's intraday bars: use an H4 or lower chart.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Expected Range indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_ExpectedRange_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_ExpectedRange_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The expected ranges, the day levels and all statistics match an independent Python calculation (all 88 days identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, 72 complete broker days: the median day used about 90% of the usual range; about 38% of days went past 100% and about 10% past 150%. Of the 27 days that reached 100%, about 44% finished at 125% or more (median 120%): reaching the usual range is not a ceiling. Descriptive only, NOT an edge. Results depend on the broker's day boundary.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
