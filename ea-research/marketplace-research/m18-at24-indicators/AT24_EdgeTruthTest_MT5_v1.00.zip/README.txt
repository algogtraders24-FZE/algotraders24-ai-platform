AT24 EDGE TRUTH TEST - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Reads the closed-trade list of the account (all trades, or only this symbol, a magic number or the last N days) and asks the hard question: could luck alone have produced this?
- A sign-flip test (a p-value for the profit against chance), a bootstrap 90% range for where the total could end up with the same trades, and the drawdown compared with the same trades in shuffled orders.
- A plain verdict: UNLIKELY TO BE PURE LUCK, CANNOT BE TOLD FROM LUCK, and so on - only with 30 or more trades.
- A pass says luck alone is unlikely for THIS list. It is not proof of a lasting edge; markets change. A built-in, clearly labelled SAMPLE list (an input) lets you see how it looks.
- Read-only: it never places or modifies trades.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Edge Truth Test indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_EdgeTruth_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_EdgeTruth_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The test engine matches an independent Python calculation (four trade lists, fourteen numbers each, with a deterministic random generator and a fixed seed). The history path was also run once on a demo account with 276 closed trades and produced a verdict.
- Real result on one broker feed: The listing screenshot uses the built-in SAMPLE trade list (clearly labelled on the dashboard): 90 sample trades, sign-flip p 0.002, verdict 'unlikely to be pure luck' - a demonstration of the display, NOT a result for any real account. On a real demo account with 276 closed trades the tool returned 'cannot be told from luck'.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
