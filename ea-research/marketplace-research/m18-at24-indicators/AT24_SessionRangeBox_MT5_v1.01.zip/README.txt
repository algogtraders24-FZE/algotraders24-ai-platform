AT24 SESSION RANGE BOX - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (boxes on your chart + one dashboard)
- The Asian session range drawn as a box every day, with a dotted extension box coloured by state: inside, broke up, broke down, no break yet.
- Live state, the box size against the median box, and a countdown to the London open.
- The last 60 days on YOUR symbol and broker data: how often the first break was up, down or none, how often a break held to the day end, how often it ran at least 1x the box, and today's box against the median.
- Optional alert on the first break (bar close only, no repaint). Session hours are set in GMT with an automatic broker-clock offset.
It never prints buy or sell arrows.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Session Range Box indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SessionBox_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SessionBox_Licensed from Navigator > Expert Advisors onto an M15 or M5 chart (best on XAUUSD or any symbol with an Asian session). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. To change session hours, open the indicator properties from the chart indicator list.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The box and break maths match an independent Python calculation (43 days compared, 0 mismatches; the statistics were identical).
- Real result on one broker feed (XAUUSD M15, last 60 GMT days, Asia 00:00-07:00 GMT, watching to 21:00): first break up about 40-43%, down about 50-52%, none about 7%; when it broke, it held to the day end about 51% of the time (about a coin flip) and ran at least 1x the box about 33%. These are historical and descriptive and differ by broker and period. They do not show an edge: our earlier scan of 25 entry rules found no cost-adjusted edge either.
- Not tested: live-money use, alerts on a live running chart. The server-to-GMT conversion uses the current offset, so days from the other side of a daylight-saving change can be one hour off.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
