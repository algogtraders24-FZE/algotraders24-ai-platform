AT24 PROP GUARD - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- TradingView cannot read your trading account, so this edition is a RISK-BUDGET CALCULATOR driven by numbers you type: account size, daily and max loss limits, the loss already used, and your risk per trade.
- It shows the limits left in money, risk per trade in money, how many full losses fit before the limit, the stop distance (ATR-based or manual) and the position size for that risk, with stop-distance lines on the chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Prop_Guard.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". Type your account numbers in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor; sample numbers checked by hand (100,000 account, 5% daily = 5,000, 0.5% risk = 500, 10 full losses to the limit). Not tested: live-money use.
- Position size is a calculation from your inputs, not advice on how large to trade. Rules differ by firm; this is not connected to or affiliated with any prop firm.
- Context tool, not a guarantee. Not financial advice.
- Support: support@algotraders24.ai
