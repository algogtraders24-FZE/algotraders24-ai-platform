AT24 WEEKEND GAP TRACKER - MetaTrader 4 version v1.00 (licensed utility Expert Advisor)

WHAT IT SHOWS
The latest market-closed (weekend) gap, whether it is filled, and how often gaps really filled on your symbol. It draws on your chart and shows a dashboard. It places NO trades and never modifies orders. Descriptive history on your broker's data: a context tool, not a signal or a forecast.

INSTALL (MetaTrader 4)
1. In MT4 choose File > Open Data Folder, open MQL4 > Experts and copy AT24_WeekendGapTracker_Licensed.ex4 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_WeekendGapTracker_Licensed onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product). Keep "Allow live trading" on only if MT4 requires it for the EA to run (the EA never trades).

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases.
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours; a short internet problem does not stop it. If the licence is invalid the EA draws nothing and says so on the chart.
- The Strategy Tester needs no key.

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings in MetaEditor 4.
- Ran on an MT4 demo terminal on XAUUSD H1: 152 gaps of at least 0.1 ATR (last 900 days): filled within 1 hour 49% against 55% for the control level, within 4 hours 65% against 72%, within 24 hours 81% against 87%, within 5 days 89% against 93%.
- Not tested: live-money use, other symbols and brokers, the licence check with a real purchase on MT4.

IMPORTANT
- Descriptive history, not a signal, a forecast or financial advice. Past behaviour does not predict future price.
- Support: support@algotraders24.ai
