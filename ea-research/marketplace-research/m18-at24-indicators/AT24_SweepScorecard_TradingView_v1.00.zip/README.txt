AT24 SWEEP SCORECARD - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- A scorecard for the popular 'Asian-range sweep' idea: every time price swept the Asian-session range and closed back inside, graded in R after a cost you set - the reversal trade, the mirror (continuation) trade and a random-direction control (their average).
- Today's state: Asian range forming, watching for a sweep, high or low swept, or no sweep today.
- The latest sweeps drawn on your chart (Asian box and a mark with the result of each), and a verdict judged by the t-statistic: lost money, made money, or not clearly different from zero.
- The rules of the graded trade are stated openly in the dashboard text. It places no trades.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Sweep_Scorecard.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 134 sweeps since 2026-01-01: reversal -0.15 R per trade, hit 44%, t -1.8; continuation -0.19 R, hit 42%; control -0.17 R; reversal minus control +0.02 R, t +0.3). Not tested: live-money use. It is a research scorecard, not a signal, and shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
