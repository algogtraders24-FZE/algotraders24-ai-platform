AT24 FORWARD LEDGER - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- A ledger of research candidate rules that were written down WITH A DATE: only what happens after each rule's registration date counts, so the numbers are out-of-sample by construction.
- For each rule: trades so far, the average return in basis points, the average net of the market's own drift, a t-statistic and a verdict that only turns positive or negative when |t| reaches 2.5 (0.05 corrected for four rules).
- Recomputed on the chart from the loaded closed bars; nothing is stored or sent.
- A clearly labelled REPLAY mode (an input date) shows how misleading in-sample numbers can be. It is not evidence.
- It places no trades.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Forward_Ledger.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, ledger open at day 1: all four rules 'collecting', 0 of 30 trades). Not tested: a full forward period - there is none yet. It is a research ledger, not a signal, and claims no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
