AT24 PROP GUARD - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (one dashboard on your chart)
- Status: WITHIN LIMITS / CAUTION (50%) / DANGER (80%) / LIMIT REACHED.
- Daily loss used (percent and money) with a gauge, and total loss used with a gauge.
- Money left today and left overall, and which limit is binding.
- Open risk if every stop loss is hit, and how many open trades have no stop.
- Profit-target progress, the day-start value and the reset hour you choose.
- Optional alerts at 80% and 95% of a limit.
It shows what YOU configure: you type your daily loss %, max loss %, target % and the day-reset hour to match your own account rules. It never closes or modifies trades.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Prop Guard indicator (built into the EA file, nothing else to install) on your chart and never places, closes or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_PropGuard_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_PropGuard_Licensed from Navigator > Expert Advisors onto a chart (any symbol). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. To set your limits, open the indicator properties from the chart indicator list (Your limits: daily loss %, max loss %, target %, initial balance, reset hour).

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings. A self-test script on a live demo account passed 22 of 22 checks (synthetic scenarios for limits, breach, profit, total loss, target progress, status levels, day start for a 17:00 reset, and the indicator values against an independent calculation).
- Run on a real MT5 chart (see the listing screenshot, demo account).
- NOT tested: open risk with real open positions. The test accounts had no open trades, so only the zero-position case was compared. Treat the open-risk line with live trades as unverified.
- Day start by "balance at reset" is rebuilt from deal history; "equity when first seen" depends on when it was first attached that day.
- Account rules differ by firm and by account (daily-loss base, reset time zone, trailing rules). The tool uses only the limits you type and is not connected to or affiliated with any prop firm.

IMPORTANT
- Context tool, not a guarantee. It does not prevent a breach and does not manage your trades. Rules differ by firm; set your own limits. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
