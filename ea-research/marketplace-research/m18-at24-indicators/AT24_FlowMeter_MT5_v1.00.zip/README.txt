AT24 FLOW METER - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- A sub-window with the per-bar delta as a histogram and the cumulative delta that restarts each day.
- A badge that says what kind of delta you are looking at: REAL when the feed flags buyer and seller trades, TICK-RULE ESTIMATE when it is estimated from ticks, or BAR PROXY when it is estimated from the bar and tick volume.
- Darker bars use tick data where your terminal has it, lighter bars are the bar-based estimate for older history.
- Delta divergence marks on the price chart, on closed bars only, and an optional alert once per bar.
- It places no orders and gives no signals.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Flow Meter indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_FlowMeter_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_FlowMeter_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The calculation matches an independent Python calculation on 83,924 real exchange trades (real and tick-rule modes) and on 3,000 XAUUSD bars (bar-based estimate and daily cumulative delta).
- Real result on one broker feed: BTCUSD M15 on an IC Markets demo feed: with the tick bars input set to 5 the badge read TICK-RULE ESTIMATE (last 5 bars from ticks, older bars from the bar proxy); with the default input the demo had no tick history and the badge read BAR PROXY. The histogram, the daily cumulative line and two delta divergence marks on closed bars were drawn, and the terminal reported no slow-indicator warning. This demo feed carries no buy/sell flags, so a real delta mode is not available on it.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
