AT24 SPREAD GUARD - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- TradingView has no historical spread data, so this edition works from the average bar RANGE per UTC hour plus the typical spread you type in the inputs: this hour's cost estimate, spread / average range, the cheapest and costliest hours (UTC), and a histogram.
- It is a cost-context tool, not a measurement of your broker real spread. For the real spread use the MetaTrader 5 edition.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol; 1 hour or lower works best).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Spread_Guard.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs. Enter your typical spread in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor. Not tested: live-money use.
- Cost tool. Not a signal. Trading in cheap hours does not make money by itself. Not financial advice.
- Support: support@algotraders24.ai
