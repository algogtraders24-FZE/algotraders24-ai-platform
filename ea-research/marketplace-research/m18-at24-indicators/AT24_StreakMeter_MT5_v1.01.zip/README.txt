AT24 STREAK METER - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- The current streak of same-colour candles on the timeframe you choose (daily by default): for example 3 D1 candles down in a row.
- A table on YOUR symbol and broker data: how often the next candle had the same colour after streaks of 1, 2, 3, 4, 5 and 6+ candles, each with the number of cases (n), a 95% interval, and the any-candle baseline - so you can judge the evidence yourself.
- A candle is up or down by its close against its open; flat candles are skipped.
- It answers the 'a reversal is due after N candles' (or 'the streak will continue') claim with your own data. Works on any chart timeframe and reads the chosen timeframe's history on demand.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Streak Meter indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_StreakMeter_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_StreakMeter_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The streak length per candle and every continuation count and percentage match an independent Python calculation (D1 and H4 tables identical).
- Real result on one broker feed: XAUUSD D1, last 3,000 daily candles: the next candle had the same colour as the last about 47% of the time (baseline 47.2%, n=2,999). After a streak of 1 candle 47% (n=1,583, +-2), 2 candles 48% (n=742), 3 candles 45% (n=354), 4 candles 52% (n=160, +-8), 5 candles 52% (n=83, +-11) and 6+ candles 44% (n=77, +-11). The rate does not depend on streak length: three or four days in a row is no more 'due for a reversal' than one, and the long-streak figures are noise. On another broker feed (953 daily candles) the baseline was 46.6% and H4 candles were around 50% throughout. Descriptive only, NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
