AT24 CORRELATION SHIFT MONITOR - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Up to 20 pairs you choose, written as A:B (for example gold against the dollar, or bitcoin against a stock index).
- For each pair: the correlation of daily returns over a short and a long window, the change between them, and where today's short-window value sits among its own history as a percentile.
- A plain status: normal, shifted or extreme, and an optional alert when a pair changes status.
- It loads in stages so the chart stays responsive. It uses prices only: no WebRequest. It places no orders and gives no signals.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Correlation Shift Monitor indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_CorrelationShift_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_CorrelationShift_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The calculation matches an independent Python calculation, including a known-answer check.
- Real result on one broker feed: Three pairs on an IC Markets demo feed (20-day and 120-day windows): the panel showed the short and long correlation, the change and the percentile for each pair, all with status normal on the day of the check.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
