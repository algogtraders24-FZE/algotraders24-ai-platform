AT24 STREAK METER - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The current streak of same-colour candles on the timeframe you choose (daily by default), for example 3 daily candles down in a row.
- A table on the history loaded on your chart: how often the next candle had the same colour after streaks of 1, 2, 3, 4, 5 and 6+ candles, each with the number of cases (n) and a 95% interval, next to the any-candle baseline.
- A candle is up or down by its close against its open; flat candles are skipped.
- It answers the 'a reversal is due after N candles' (or 'the streak will continue') claim with your own data.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Streak_Meter.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD, daily candles: baseline 47% same colour, after streaks of 1, 2, 3, 4, 5 and 6+ candles 48%, 46%, 47%, 47%, 48% and 50%). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
