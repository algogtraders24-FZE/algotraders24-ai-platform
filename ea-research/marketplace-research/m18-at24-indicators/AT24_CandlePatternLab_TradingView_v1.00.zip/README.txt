AT24 CANDLE PATTERN LAB - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- Bullish and bearish engulfing candles and bullish and bearish pin bars on closed bars, marked on your chart (small candles below a chosen ATR size are ignored as noise).
- What the last closed candle is, if any pattern.
- Statistics on the history loaded on your chart: for each pattern, how many cases, how often price moved the pattern's way over the next 6 bars (with a 95% interval), next to the same rate for any bar - so you can see for yourself whether the pattern added anything.
- Closed bars only, so the marks do not repaint.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Candle_Pattern_Lab.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 10,900 bars, next 6 bars: bullish engulfing n=627 48% vs 53% any bar, bearish engulfing n=645 49% vs 47%, bullish pin bar n=746 52% vs 53%, bearish pin bar n=667 46% vs 47%). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
