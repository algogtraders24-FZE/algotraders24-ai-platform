AT24 ABSORPTION MAP - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Zones marked where heavy tick volume met a small price range after a push, drawn on the chart on closed bars only.
- A ready plan for the nearest fresh zone on each side: limit price, stop and a 2R target.
- First-retest scorecards for every past zone on the symbol's own history: retests, hit rate, average R after cost, and a sign-flip luck test.
- A verdict that only says POSITIVE or NEGATIVE ON THIS HISTORY when the result is beyond luck; otherwise NO EDGE SHOWN, and TOO FEW under 30.
- Optional touch alert once per bar. It uses tick volume per bar only. It places no orders.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Absorption Map indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_AbsorptionMap_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_AbsorptionMap_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The whole chain (zones, retests, trades, scorecards) matches an independent Python calculation (94 zones, 89 trades, all identical).
- Real result on one broker feed: XAUUSD M15 on an IC Markets demo feed: sellers-absorbed zones 67 retests, hit rate 40%, average +0.17 R after cost (luck test p 0.19, NO EDGE SHOWN); buyers-absorbed zones 47 retests, hit rate 23%, average -0.34 R (NEGATIVE ON THIS HISTORY); all zones 114 retests, average -0.04 R (p 0.62, NO EDGE SHOWN). Hindsight on past bars, no edge claimed.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
