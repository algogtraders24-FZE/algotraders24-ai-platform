AT24 VOLATILITY FORECAST - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- A forecast of the size of the next move over a horizon you choose (8 hours by default): the 1-sigma and 2-sigma move in price and in percent, drawn as a band from the last close.
- A volatility state - LOW, NORMAL, HIGH or VERY HIGH - from the percentile of the current volatility level against recent history, with the time-of-day pattern removed, and how many times its normal level it is now.
- A calibration study on the history loaded on your chart: how well the forecast tracked the volatility that really followed (correlation and the share of windows within +-30%), next to a plain average and an ATR(14)-only forecast.
- Size of moves, NOT direction. Closed bars only; use a 1h or lower chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Volatility_Forecast.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 974 windows of 8 hours: forecast correlation 0.64 with 53% of windows within +-30%; plain average 0.59 / 49%; ATR(14) only 0.60 / 28%, running 43% low). Not tested: live-money use. It forecasts the size of moves, not direction, and shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
