AT24 PERSISTENCE METER - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The variance ratio (VR) of price moves over three horizons on your chart, with a z-statistic and the implied exponent: above 1 means moves tended to continue, below 1 to reverse, near 1 a random walk.
- A state for the main horizon: MOVES TEND TO CONTINUE, MOVES TEND TO REVERSE or LOOKS LIKE A RANDOM WALK, judged by the z-statistic against a threshold you set.
- A study on the history loaded on your chart: how much of the time each state occurred, and how often the next move went the same way as the previous move - any time, when trending and when reverting - each with its sample size and a 95% interval.
- A small z-statistic line in a separate pane. Uses closed bars; works on any timeframe.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Persistence_Meter.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h: 327 study windows, the next move went the same way as the last move 49% of the time; trending 47% (n=15), reverting 58% (n=24); state at the time: random walk, VR 1.11 at 8 bars). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
