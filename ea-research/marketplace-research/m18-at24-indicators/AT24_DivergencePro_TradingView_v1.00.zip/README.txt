AT24 DIVERGENCE PRO - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- RSI divergences marked on the chart, using a swing point only after the bars to its right have closed, so nothing repaints (the signal arrives a few bars after the swing).
- A plan for a live divergence on the last closed bar: entry, stop beyond the swing extreme and a target.
- Scorecards for bullish, bearish and all divergences on this chart's own loaded history: trades, hit rate, average R after a cost you set, total R.
- A chance check: a sign-flip luck test. A verdict turns positive or negative only beyond luck; otherwise it reads NO EDGE SHOWN, and TOO FEW under 30 trades.
- Recomputed on the chart from the loaded bars; nothing is stored or sent. It places no trades.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 15m chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Divergence_Pro.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 15m: 86 divergences, 39 bullish and 37 bearish trades scored, all groups reading no edge shown). Not tested: other symbols and timeframes, a live divergence block, alerts. Research tool, not a signal, and claims no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
