AT24 COST CLOCK - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- For every New York hour: the broker's bar-level spread as a share of the typical (median) hourly range of that hour - what the hour costs you per unit of move.
- The current New York hour rated CHEAP, AVERAGE or COSTLY with its rank among the hours, a 24-hour colour strip, and the cheapest and costliest hours as lists.
- Built from the last 365 days of your own broker's H1 history; the broker clock (server time and daylight rule) is detected automatically, trying other FX pairs if needed, and can be set by hand.
- A cheap hour is not a good trade; it only costs less per move. Cost context, not a signal.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Cost Clock indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_CostClock_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_CostClock_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The cost engine matches an independent Python calculation for all 24 hours, and the New York hour matches the zoneinfo reference on 34,997 bars.
- Real result on one broker feed: XAUUSD on one broker demo feed, last 365 days: at NY 11:00 the spread was 0.05 = 0.2% of the typical hour range (rank 5 of 23, rated CHEAP); the cheapest hours were 09, 08, 10, 21, 11 and the costliest 16, 00, 23, 06. Cost context only: a cheap hour is not a good trade.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
