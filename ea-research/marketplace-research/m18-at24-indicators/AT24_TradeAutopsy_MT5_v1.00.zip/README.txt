AT24 TRADE AUTOPSY - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Draws the closed trades of the chart symbol on the chart (the last N trades) and measures, on YOUR own trades, how they behaved against the price path around them.
- Exits: the share of the best price the exit captured for winners, how many winners saw price go at least as far again within N bars, and the share of trades closed with under half of their best price.
- Pain: how far winners dipped against you on average, and how many losers came back to your entry within N bars.
- Risk: the average result in R for trades that had a stop.
- Hindsight statistics: they show what price did, not what you could have done. Read-only; it never places or modifies trades. A built-in, clearly labelled SAMPLE list (an input) lets you see the display.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Trade Autopsy indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_TradeAutopsy_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_TradeAutopsy_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The trade-measurement engine matches an independent Python calculation (150 synthetic trades with five values each, plus the summary, all identical). The deal pairing was also run once on a demo account with 257 closed trades on the chart symbol and produced a full dashboard.
- Real result on one broker feed: The listing screenshot uses the built-in SAMPLE trades (labelled 'SAMPLE TRADES - NOT YOURS'): it only shows how the display works and is NOT a result for any real account. Run once on a real demo account with 257 closed trades, the tool paired the deals and produced all its statistics.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
