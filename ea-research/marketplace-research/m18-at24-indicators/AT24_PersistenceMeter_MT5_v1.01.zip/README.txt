AT24 PERSISTENCE METER - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- A standard statistical test (Lo-MacKinlay variance ratio) on the last bars at three move lengths (4, 8 and 16 bars): the variance ratio, its z-score and a Hurst-style exponent, and a plain-words state: MOVES TEND TO CONTINUE / MOVES TEND TO REVERSE / LOOKS RANDOM.
- A study on YOUR symbol and broker data: how often the reading was each state, and whether the next move really went the same way as the last one - overall, when the meter said continue and when it said reverse - always shown with the number of windows and a 95% interval.
- It reads the sign of serial correlation in the recent window only; it can flip quickly and changes with window and move length.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Persistence Meter indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_Persistence_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_Persistence_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The variance ratio, z-statistic and exponent match an independent Python calculation (90 spot checks) and the full study is identical.
- Real result on one broker feed: XAUUSD M15, 234 non-overlapping 32-bar windows: the meter said moves tend to continue in about 3% of windows (7 windows), tend to reverse in about 18% (43) and random in about 79%. The next move went the same way as the last one about 54% of the time overall (+-6 points). When the meter said continue it was about 71%, but on only 7 windows (+-33 points); when it said reverse it was about 49% on 43 windows (+-15). Neither differs from the overall rate beyond noise: on this sample the reading did not demonstrably predict the next move. Descriptive only, NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
