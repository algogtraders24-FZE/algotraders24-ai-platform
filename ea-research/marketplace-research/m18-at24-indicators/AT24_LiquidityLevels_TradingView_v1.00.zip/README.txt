AT24 LIQUIDITY LEVELS - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- The previous day, week and month high and low as lines with their state (untouched, swept, accepted), a dashboard table with the sweep statistics of the last 60 days (how often the previous-day high and low were swept and what the day did next).
- Day, week and month boundaries follow the symbol exchange session (for example OANDA uses 17:00 New York), so numbers differ slightly from the MetaTrader 5 edition which uses GMT days.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (1 hour or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Liquidity_Levels.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 60 days: previous-day high swept 43%, low 60%, either 90%; back inside after a sweep 58%). Not tested: live-money use. Descriptive history, no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
