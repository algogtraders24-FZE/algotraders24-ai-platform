AT24 HOUR BIAS MAP - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- A histogram of the mean return per New York hour (in basis points, daylight-saving aware, checked against the standard time-zone database), with the current hour highlighted and its t-statistic, share of up hours and sample size.
- The check most posts skip: how many of the 24 hours look significant (|t| >= 1.96 and |t| >= 3) compared with what chance alone gives (about one), and whether the pattern in the first half of the history held in the second half (correlation and how many hours kept the same sign).
- It uses the symbol's H1 history (900 days by default) and works on any chart timeframe; it waits until the terminal has built the history, so the first display can take a few seconds.
- It teaches the multiple-comparisons problem on your own data and never claims an hour is tradable.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Hour Bias Map indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_HourBias_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_HourBias_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The New York hour conversion equals the standard time-zone database on all 15,485 hourly bars, and the per-hour statistics, significance counts and the half-to-half check match an independent Python calculation (identical).
- Real result on one broker feed: On one broker feed (XAUUSD H1, 15,485 hourly bars, about 2.6 years) exactly one of 23 New York hours was statistically clear: NY 18:00, the first hour after the daily break, at about +3.8 bp per hour (t 3.67, price up in 58.7% of those hours, positive in both halves of the history). Every other hour was within chance, and the first-half pattern did not predict the second half (correlation -0.04). On our IC Markets demo feed (21,650 hourly bars) the same picture: 1 hour with |t| >= 3, 1 with |t| >= 1.96 (chance would give about 1), and only 10 of 24 hours kept the same sign in both halves (correlation +0.01). Gold rose strongly over the period, which lifts most hours. Descriptive only, NOT an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
