AT24 EFFECT TRACKER - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- For each of the 24 New York hours: the mean return and t-statistic in the latest window and in the window before, and a status - ALIVE (significant in both with the same sign), NEWBORN (only the latest), DIED (only the earlier) or no effect.
- How many hours are significant now against what chance alone gives (about one in 24 at |t| of 2).
- The hours that changed status first, each with the most likely change point of its average (a CUSUM test over the last three windows).
- Window length and the t threshold are inputs. A TradingView chart holds fewer days than a broker terminal, so the default windows are 60 trading days.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Effect_Tracker.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 60-day windows: 1 of 24 New York hours significant now against about 1.1 expected by chance; alive 0, newborn 1, died 3). Not tested: live-money use. It is a research tool, not a signal, and shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
