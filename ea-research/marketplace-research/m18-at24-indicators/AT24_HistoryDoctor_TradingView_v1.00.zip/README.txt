AT24 HISTORY DOCTOR - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- A verdict on the hourly history loaded on your chart: CLEAN, PARTLY USABLE, BROKEN BARS FOUND or NO HOURLY HISTORY.
- The first date from which the history is really hourly (a day with 20 or more hourly bars).
- A table per year: bars and the number of fully hourly days out of the days seen.
- Broken bars (high below low, prices outside the bar), order errors and missing hours inside trading weeks.
- A plain warning not to trust hour-of-day statistics before the 'hourly from' date. Spread coverage is not available on TradingView; the MetaTrader editions audit it.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_History_Doctor.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 5,083 hourly bars loaded: verdict CLEAN, 0 broken bars, 0 order errors, 12 missing hours, 219 of 268 days fully hourly). Not tested: other symbols and exchanges. It audits data completeness and consistency only and shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
