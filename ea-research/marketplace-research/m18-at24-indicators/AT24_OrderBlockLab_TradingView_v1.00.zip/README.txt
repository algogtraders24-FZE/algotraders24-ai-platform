AT24 ORDER BLOCK LAB - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- Order blocks on closed bars - the last opposite-colour candle before a strong move, confirmed only after the move closes - drawn as zones for the newest untouched blocks, with the nearest block above and below price.
- A study on the history loaded on your chart: how many blocks, how often price came back to the block within a window, and how often it reacted away before breaking the level - each next to a control zone mirrored through the confirming price.
- The definition is stated openly in the dashboard text. Closed bars only, so nothing repaints.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Order_Block_Lab.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 307 measured blocks: price came back within 100 bars 81% against 76% for the control zone; reacted away 51% (n=249) against 50% (n=283)). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
