AT24 HISTORY DOCTOR - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- A verdict on the hourly history of the symbol you attach it to: CLEAN, PARTLY USABLE, BROKEN or NO HOURLY.
- The first date from which the history is really hourly (some brokers store older years as two bars per day).
- A table per year: bars, days with a full hourly day, and the share of bars whose spread field is empty (0) - so you know from which year spread-based statistics can be trusted.
- Broken bars (high below low, prices outside the bar), order errors, and missing hours inside trading weeks.
- A plain warning: do not trust hour-of-day or spread statistics before the dates it names. Audit of your own terminal data; not a signal.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the History Doctor indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_HistDoctor_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_HistDoctor_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The audit engine matches an independent Python calculation on 34,997 real XAUUSD hourly bars and on a deliberately corrupted copy (every injected fault found, numbers identical).
- Real result on one broker feed: XAUUSD on one broker demo feed, 40,000 hourly bars audited: verdict PARTLY USABLE. Hourly data usable from 2020-02-06; the spread field was zero on 6% of bars in 2020, 93% in 2021, 91% in 2022, 56% in 2023, 16% in 2024, 28% in 2025 and 26% in 2026; 0 broken bars, 0 order errors, 248 missing hours in 45 breaks. Completeness and consistency only - it says nothing about whether any strategy works.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
