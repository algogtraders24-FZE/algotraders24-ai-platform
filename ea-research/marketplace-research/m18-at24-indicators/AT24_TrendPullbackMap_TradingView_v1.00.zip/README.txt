AT24 TREND PULLBACK MAP - TradingView version v1.00 (Pine Script)

WHAT IT SHOWS
- An EMA 20 / 50 / 200 ribbon with the mid EMA coloured by trend, triangles where price touched the fast EMA inside a trend (not buy or sell arrows), and a dashboard table: trend, zone, price distance from the fast EMA in ATR, pullbacks resolved, how often the trend resumed versus failed, median depth.
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Trend_Pullback_Map.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 566 resolved touches: trend resumed 29%, failed 56%, neither 15%, median depth 4.2 ATR). Not tested: live-money use. Descriptive history; it shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
