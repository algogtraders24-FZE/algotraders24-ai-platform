AT24 VOLUME PROFILE LEVELS - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- Yesterday's volume profile from tick volume: the point of control (POC, the busiest price) and the value area (VAH / VAL, 70% of the volume), drawn on your chart with the value area shaded.
- Where price is now: inside, above or below yesterday's value area, and how far from the POC.
- A study on the history loaded on your chart: how often price touched yesterday's POC, VAH and VAL, and how often it reacted away from the level before breaking it - each next to a control level mirrored through the day's open.
- Tick volume from your data feed, not exchange volume. Use an intraday chart; closed bars only.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, intraday).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Volume_Profile_Levels.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, last 300 days: yesterday's POC touched 65% of days (control 65%), VAH 62% (60%), VAL 59% (65%); reacted away 47% / 45% / 55% against controls of 46% / 51% / 51%). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
