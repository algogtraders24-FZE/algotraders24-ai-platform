AT24 WEEKDAY BIAS MAP - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The mean daily return of every weekday (Monday to Friday) in basis points as a strip on your chart, with today highlighted and significant days starred.
- The verdict: no weekday stands out, or a weekday stands out in the past data, judged by the t-statistic.
- The t-statistic per weekday, how many of the five weekdays reach |t| of 1.96 (chance alone gives about 0.25), and in how many weekdays both halves of the history agree in sign, with the correlation of the two halves.
- Daily candles are rebuilt from the chart bars (exchange day), so a daily chart gives the longest history; the table says when there are fewer than 300 candles.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, a daily chart gives the longest history).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Weekday_Bias_Map.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor on a daily OANDA XAUUSD chart (14,887 daily candles: 1 of 5 weekdays with |t| of 1.96 or more - Friday t +3.54; Monday -1.22, Tuesday +1.14, Wednesday +0.95; the same sign in both halves for 4 weekdays, correlation of the halves +0.30). Not tested: live-money use. A weekday result in past data is not a forecast and shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
