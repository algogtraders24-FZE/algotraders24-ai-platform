AT24 HOUR BIAS MAP - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The mean return of every New York hour (0 to 23) in basis points, with a t-statistic and the share of up bars, drawn as a 24-hour strip and a table on your chart.
- The verdict for the current New York hour: no bias, weak bias or clear bias in the past data - judged by the t-statistic, not by eye.
- How many of the 24 hours look significant against what chance alone gives (about 1 of 24 at |t| of 1.96), and how many reach |t| of 3.
- Whether the pattern held: the same sign in both halves of the history, and the correlation between the 24 first-half means and the 24 second-half means.
- Works on the 1h chart, uses the history loaded on your chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h chart).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Hour_Bias_Map.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 10,906 hourly bars: 3 of 24 hours with |t| >= 1.96, none with |t| >= 3; same sign in both halves for 12 of 24 hours, correlation +0.51). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
