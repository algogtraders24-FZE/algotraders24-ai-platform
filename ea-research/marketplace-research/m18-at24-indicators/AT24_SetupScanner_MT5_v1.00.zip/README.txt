AT24 SETUP SCANNER - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- A watchlist table for up to 20 symbols: the trend, any setup on the last closed bar with entry, stop and target, and each setup type's record on that symbol's own history.
- Per symbol and setup type: setups, average R after cost, and a sign-flip luck test with a plain verdict (PASS only beyond luck, otherwise none).
- A chance reminder: how many scorecards would pass by luck alone across the list.
- Closed bars only (nothing repaints). Optional alert and push when a new setup forms on any symbol. It places no orders.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Setup Scanner indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SetupScanner_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SetupScanner_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The engine matches an independent Python calculation on two symbols.
- Real result on one broker feed: Eight symbols on one broker demo feed (H1 scorecards): 1 of 16 scorecards beat luck, against about 0.8 expected by chance alone; most read none. Hindsight statistics on past bars only.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
