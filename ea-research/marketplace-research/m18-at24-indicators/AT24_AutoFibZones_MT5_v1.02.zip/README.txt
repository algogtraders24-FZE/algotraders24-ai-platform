AT24 AUTO FIB ZONES - MetaTrader 5 version v1.02 (licensed utility EA)

WHAT IT SHOWS
- Fibonacci levels 0 / 23.6 / 38.2 / 50 / 61.8 / 78.6 / 100 % drawn on the last CONFIRMED swing leg, with the 38.2-61.8 zone shaded and the leg itself drawn.
- Swings are found by a fixed rule (a bar that is the highest or lowest of N bars on each side, default 5, confirmed N bars later), so the levels do not repaint and do not depend on where you click.
- How deep price has pulled back into the last leg so far.
- Statistics on YOUR symbol and broker data: the median pullback depth, how often a pullback reached 38.2 / 50 / 61.8 %, how often it went past 100 %, and how often the leg's extreme was beaten.
- Optional alert when a pullback reaches 38.2 % (bar close, no repaint).

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Auto Fib Zones indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_AutoFib_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_AutoFib_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The swings, legs and statistics match an independent Python calculation (785 swings and 782 legs identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, last 8,000 closed bars, about 790 legs with a 5-bar swing: pullbacks took back a median of about 97 % of the leg; about 48 % went past 100 %; the leg's extreme was beaten about 48 % of the time (a coin flip). A control test showed pullback depths do NOT cluster at 38.2 / 50 / 61.8 % more than at other values: the levels are a reference grid, not magic numbers. Descriptive only, NOT an edge. Other swing sizes give other legs and numbers.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
