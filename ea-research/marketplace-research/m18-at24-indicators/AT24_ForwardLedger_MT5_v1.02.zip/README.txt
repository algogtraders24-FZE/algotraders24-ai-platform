AT24 FORWARD LEDGER - MetaTrader 5 version v1.02 (licensed utility EA)

WHAT IT SHOWS
- A ledger of five research candidate rules (one of them tied to the broker's USD economic calendar) that were written down WITH A DATE: only what happens after each rule's registration date counts, so the numbers are out-of-sample by construction.
- For each rule: trades so far, the average return in basis points, the average net of the market's own drift, a t-statistic and a verdict that only turns positive or negative when the result beats chance after correcting for the number of rules registered.
- All numbers are recomputed from your own broker's closed hourly bars; nothing is stored or sent.
- A clearly labelled REPLAY mode (an input) shows how misleading in-sample numbers can be. It is not evidence.
- Rules are only added with later dates and never edited. It places no trades.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Forward Ledger indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_ForwardLedger_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_ForwardLedger_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The ledger engine matches an independent Python calculation (all numbers identical for the registered rules from three start dates, and the New York hour on 34,967 bars).
- Real result on one broker feed: After four days the ledger shows every rule still 'collecting' (fewer than 30 trades each; the fifth rule has none yet) - the honest starting point. A rule only gets a verdict after enough trades, and only when it beats chance after correcting for the number of rules registered (five). Most ideas never will; that is the point of the ledger.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
