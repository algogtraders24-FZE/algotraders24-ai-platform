AT24 TRADE PLANNER - MetaTrader 5 version v1.00 (licensed utility EA)

WHAT IT SHOWS
- Three draggable lines on your chart - Entry, Stop and Target - and a panel that updates as you move them.
- Lot size for your risk rule (a percentage of the balance or a fixed amount of money), the money you lose at the stop and win at the target, and the reward-to-risk ratio.
- The margin the trade needs, and spread plus commission as a share of the reward.
- The share of today's remaining daily loss allowance the trade would use - useful with prop-firm rules.
- It checks that the stop is on the right side of the entry. A calculator only: it places no orders.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Trade Planner indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_TradePlanner_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_TradePlanner_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The planning engine matches an independent Python calculation (eight long and short scenarios, and a wrong-side stop is rejected). On the demo terminal the money figures matched the contract-size arithmetic (0.01 lot of XAUUSD with a 14.08 stop gave 14.08 USD at the stop and 28.16 USD at the target).
- Real result on one broker feed: Calculator, not a result product: on the demo terminal a 0.01 lot XAUUSD plan with a 14.08 stop and 28.16 target showed 14.08 USD at risk and 28.16 USD at the target, matching the contract-size arithmetic. Not yet checked against the platform's order calculator or margin on a live quote.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
