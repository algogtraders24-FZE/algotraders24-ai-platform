AT24 VOLATILITY FORECAST - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- A volatility estimate from open/high/low/close (four range estimators), with gold's time-of-day pattern removed using only past bars (no look-ahead).
- The expected 1-sigma and 2-sigma move for the next 8 hours, drawn as bands on your chart, and a volatility regime with its percentile (for example VERY HIGH, 100th percentile, 2.3x its normal level).
- A calibration table on YOUR symbol and broker data: how well the forecast tracked the volatility that really followed, against a plain average and against ATR(14) - correlation, share of windows within +-30%, and how far ATR runs low.
- It shows the SIZE of moves only, never their direction. H1 or lower charts only.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Volatility Forecast indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_VolForecast_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_VolForecast_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- All eight forecasts, the calibration table, the volatility level and the percentile match an independent Python calculation (identical on 8,000 bars).
- Real result on one broker feed: XAUUSD M15, 243 non-overlapping 8-hour windows: the time-of-day-aware forecast tracked the volatility that followed with a correlation of about 0.40 and 74% of windows within +-30%, against about 0.10 and 60% for a plain average and about 0.11 and 36% for ATR(14), which ran about 34% low. A correlation of 0.4 is moderate, not strong. It is the size of moves, not their direction, and not an edge.
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
