AT24 NY OPENING RANGE - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The 09:30-10:00 New York opening range as a box on your chart, coloured by outcome (not broken, broke up, broke down, no break). New York time follows daylight saving automatically.
- A dashboard: state (opens in n minutes, forming, set, broken), the range and the New York time now.
- Statistics on the days loaded on your chart: how often the range broke up, down or not at all, how often the break held to the window end (16:00 New York), how often it ran one box height, and how often it fell back inside within 4 bars.
- A control window at 11:00 (same length) so you can see whether the opening range behaves any differently from an ordinary window.
- Use a 30-minute or lower chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 30 minutes or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_NY_Opening_Range.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 15m, 67 days: up 39%, down 61%; the break held to 16:00 on 60%, ran one box height on 57% and fell back inside within 4 bars on 55%; the 11:00 control window: held 57%, fell back 63%, ran 52%). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
