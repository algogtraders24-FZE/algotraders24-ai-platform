AT24 DAILY RISK PANEL - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS
- You enter your own rules: the daily loss limit in percent, the maximum risk per trade, the maximum total open risk and the maximum trades per day.
- The panel shows today's result as a share of your daily limit (a green-to-red gauge), the trades opened today, the risk of open positions to their stops, the positions without a stop, and a 'rules broken today' counter with the last break.
- Each broken rule is counted once per day and alerts once. It only warns: it never closes, blocks or modifies a trade.
- The day starts at the broker hour you choose; the day-start balance is the balance now minus today's deal flows. A position with no stop counts as a broken rule because its real risk is unbounded.

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Daily Risk Panel indicator (built into the EA file, nothing else to install) on your chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_DailyRisk_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_DailyRisk_Licensed from Navigator > Expert Advisors onto a chart (any symbol and timeframe). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. The first draw can take a minute while history loads.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart (see the listing screenshot).
- The core arithmetic matches an independent calculation on six scenarios (all identical), and on a real demo account on a losing day the panel counted two broken rules (daily loss and trades per day) with a day result of 228% of the limit, which matches hand arithmetic.
- Real result on one broker feed: This is a tracker, not a strategy: it has no trading results. On a real demo account on a losing day it showed the day result at 228% of a 3% daily limit, 33 trades opened against a limit of 5, and 'rules broken today: 2' with the time of the last break; the figures match hand arithmetic. Open-position risk and the 'position without a stop' rule were verified through the core only (no open position was available at the time).
- Not tested: live-money use, alerts beyond a screenshot, the licence check with a real purchase.

IMPORTANT
- Descriptive history on your own broker data. Context tool, not a signal or a forecast. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
