AT24 WEEKEND GAP TRACKER - TradingView version v1.00 (Pine Script v5)

WHAT IT SHOWS
- The latest market-closed (weekend) gap: size in price and in ATR, direction, when the market reopened, and whether the old close has been reached again (filled), drawn as a zone and a line on your chart.
- Statistics on the history loaded on your chart: how many gaps were measured, how often they were up, the typical size in ATR, and how often a gap filled within 1 hour, 4 hours, 24 hours and 5 days, each next to a control level at the same distance on the other side.
- Works on closed bars, so the figures do not repaint. Use a 1h or lower chart.

HOW TO ADD IT (takes a minute)
1. Open a TradingView chart (any symbol and timeframe, 1h or lower).
2. Open the Pine Editor (bottom panel), choose the script menu > Create new > Indicator, select all the text and delete it.
3. Open AT24_Weekend_Gap_Tracker.pine from this zip in any text editor, copy everything and paste it into the Pine Editor.
4. Press "Add to chart". The dashboard appears in the corner you chose in the inputs.
5. Optional: press Save in the Pine Editor to keep the script in your own account.

THINGS TO KNOW
- TradingView uses all the bars loaded on your chart, so counts differ from the MetaTrader 5 edition by timeframe and history.
- Plain Pine Script source with no web access. TradingView cannot check a licence key inside a script, so on TradingView the licence is the purchase itself: the file is delivered to your AT24 account for use on your own TradingView account. Please do not publish or share it.
- Tested: compiles and renders in the Pine Editor (OANDA XAUUSD 1h, 84 gaps of at least 0.1 ATR: filled within 1 h 33% (control 44%), 4 h 55% (58%), 24 h 70% (81%), 5 days 85% (88%)). Not tested: live-money use. It shows no edge.
- Descriptive history. Context tool, not a signal or a forecast. Not financial advice.
- Support: support@algotraders24.ai
