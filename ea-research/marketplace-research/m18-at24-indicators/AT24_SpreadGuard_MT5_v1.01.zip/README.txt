AT24 SPREAD GUARD - MetaTrader 5 version v1.01 (licensed utility EA)

WHAT IT SHOWS (one dashboard + one sub-window)
- Live spread now against the typical spread for this GMT hour, status NORMAL / ELEVATED / SPIKE.
- Spread as a share of ATR(14) with a HIGH COST warning.
- The 3 cheapest and 3 costliest hours (GMT) and a 24-hour mini chart of the hourly spread profile (gold bar = current hour).
- A coloured spread histogram with the typical-hour line in its own window. Optional alert when the spread spikes.
- The profile is learned from YOUR broker: from the spread stored on the bars and, when that history is flat, from the live spread over time (kept in terminal global variables, survives restarts). The panel says which source it uses. In the first hours or days of the live profile it says "learning".

INSTALL (MetaTrader 5) - this product is a licensed UTILITY EXPERT ADVISOR
It loads the Spread Guard indicator (built into the EA file, nothing else to install) in its own window below the chart and never places or modifies orders. It is an Expert Advisor only because MetaTrader does not let indicators check a licence online.
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SpreadGuard_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SpreadGuard_Licensed from Navigator > Expert Advisors onto a chart (any symbol). On the Inputs tab paste your licence key into "InpLicenseKey" (AT24 dashboard: Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on so the EA can run. Leave the chart open for the live profile to learn. To change settings, open the indicator properties from the chart indicator list.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it to another account yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked when the EA starts and every 4 hours. A short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key (the dashboard is off there unless you enable it and run in visual mode).

WHAT WE TESTED (honest summary)
- Compiled with 0 errors and 0 warnings and run on a real MT5 XAUUSD M15 chart.
- The hourly profile matches an independent Python calculation on 6,000 XAUUSD M15 bars (mean per hour differs by at most 4e-7).
- Real finding: on some brokers (for example an IC Markets Raw demo feed) the spread stored on historical bars is the same at every hour, so a history-only profile tells you nothing; that is why the live-learning profile exists. On other feeds the stored history works. If your broker stores no bar spreads the histogram stays empty and the panel relies on the live profile.
- Gold fact from our own research: with about 30 points of cost, M1 gold gives away about half the risk unit to costs and M5 about a quarter.
- Not tested: live-money use, alerts on a live feed, daylight-saving boundaries (bars from the other half of a daylight-saving year can be off by one hour).

IMPORTANT
- Cost tool. Not a signal. It does not say when to trade. Trading in cheap hours does not make money by itself. Past conditions do not predict future results. Not financial advice.
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
