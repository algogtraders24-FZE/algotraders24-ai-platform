AT24 Gold Breakout Scalper v1.12  -  Expert Advisor for XAUUSD (gold), MetaTrader 5
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

FILES
  GoldBreakoutScalper.ex5   the Expert Advisor

LICENCE KEY (required)
  Your key is on your AT24 purchase page (Dashboard > Purchases > this product > "Your licence key").
  1. MetaTrader 5: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add
        https://www.algotraders24.ai
  2. Attach the EA to an XAUUSD chart (M5 or M1), Allow Algo Trading, paste the key into InpLicenseKey.
  One key works on ONE trading account at a time and only for this product. To move it: Dashboard > Purchases > this
  product > "Change trading account" (2 changes per 30 days). The EA checks the key at start and every 4 hours; if it is
  revoked or used on another account it stops opening NEW trades (open trades are still managed). A short internet
  outage never stops a running EA (72 hours of grace). The Strategy Tester needs no key.

WHAT IS NEW IN v1.12 (compared with the first release v1.00)
  * Works on the chart symbol only and only on gold (no symbol auto-detection).
  * Trading costs are part of the logic: spread, your broker's commission (InpCommissionPerLotUSD, ROUND TURN per lot) and
    a slippage allowance. Breakeven sits at entry + cost, the trailing stop never trails inside the cost, and no trade is
    taken when the ATR is too small compared with the cost (InpMinATRtoCost).
  * Real trend filter, stale pending orders are rebuilt every bar, entry session hours (server time), Friday and panic
    handling, stop-modification throttling and broker freeze/stops-level handling.
  * Lot size: LOT_FIXED (the lot you type) or LOT_AUTO (grows with the account and shrinks with it, 0.01 lot per 1000 by
    default), with a risk cap per trade (InpMaxRiskPercent, hard stop-loss based).
  * A chart dashboard (never shown in the Strategy Tester unless you switch it on).

IMPORTANT - READ BEFORE USING
  * v1.12 has NOT been validated by the marketplace evidence. The evidence on the listing belongs to the first release
    (v1.00). In the seller's own Strategy Tester runs on REAL ticks (XAUUSD M5, October 2026) the default settings were
    around break-even; a wider exit (InpSL_Points 800, InpBreakEven_Points 300, InpTrail_Points 300) did better in that
    one month, but one month proves nothing. Backtests on 1-minute OHLC data look far better than real ticks - use real
    ticks.
  * Set InpCommissionPerLotUSD to the REAL round-turn commission of your account (0 if there is none).
  * Start on a DEMO account with a small lot. Past performance is not a guarantee of future results. Trading leveraged
    products is risky; this is not financial advice.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
