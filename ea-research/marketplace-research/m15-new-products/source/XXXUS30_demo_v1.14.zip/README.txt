XXX US30 - 30-day DEMO  (v1.14)  -  Expert Advisor for MetaTrader 5
=================================================================
Algotraders24 AI  |  https://www.algotraders24.ai

THIS IS A DEMO. Run it on a DEMO account only. It is a free 30-day trial of the product sold on the AT24 marketplace.

INSTALL (3 minutes)
 1. MetaTrader 5: File > Open Data Folder > MQL5 > Experts: copy XXXUS30_demo.ex5 there, refresh the Navigator.
 2. Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add  https://www.algotraders24.ai
 3. Open a US30 chart of your DEMO broker (M15) and drag XXXUS30_demo onto it. Allow Algo Trading.
 4. Paste your licence key into InpLicenseKey (dashboard > Purchases > this product > "Your licence key"), choose the lot size, OK.

LICENCE: 30 days, ONE trading account. After that the EA stops opening new trades (open trades are still managed). It needs internet
access to algotraders24.ai to start.

LOT SIZE: InpSizingMode RISK (default) risks InpRiskPercent (0.5) of the balance per trade; FIXED uses InpFixedLot. Check what one point is
worth at YOUR broker before choosing. Start small.

WHAT TO EXPECT
 * Results vary; losing stretches happen. 30 days is a short sample and proves nothing about the next month.
 * Demo is not live: spread, slippage and execution differ on a real account. This build refuses real accounts on purpose.
 * Past results do not predict future results. Trading leveraged products is risky; this is not financial advice.

DEMO CONTEST (optional): keep InpMagicNumber at 33302, connect the demo account to AT24 Live Sync (free) and enter on
algotraders24.ai/contest. Rules and leaderboard are on the contest page.

SUPPORT: https://www.algotraders24.ai  (dashboard > Support)
