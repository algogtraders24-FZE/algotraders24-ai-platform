AT24 TRADE MANAGER - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Trade Manager is a chart panel for manual traders. It calculates the lot size from your risk, places the order with your stop loss and take profit lines, manages open positions and can lock the account when a loss limit is reached.

What it does

- Lot size from risk: percent of balance, percent of equity or a fixed amount. Drag the SL and TP lines on the chart and the panel shows the stop distance, the reward to risk ratio and the lot size before you click.

- BUY and SELL buttons send a market order with the stop loss and take profit from the lines. Orders are refused when the stop is on the wrong side, too close for the broker, or when free margin is not enough.

- Spread check: a warning appears when the spread is a large share of the stop distance.

- Break-even, partial close and trailing stop, each can be switched on or off from the panel. Trailing modes: fixed points, ATR or the last closed candles.

- Buttons: break-even now, close half, close all, flip the lines for a sell setup, change the risk step by step.

- Account lock: set a daily loss limit and a drawdown limit from peak equity. When a limit is reached the panel can close all positions, delete pending orders, block new orders and send an alert and a push message. The daily lock resets on the next server day.

Points to know

- The utility places no trades by itself. It acts only when you press a button, and it manages positions with the rules you set.

- It works on the symbol of the chart where it runs. Managed positions can be all positions of that symbol or only the ones opened from the panel.

- The account lock closes all positions of the account when it triggers, also those of other expert advisors. Set the limits with this in mind.

- Market orders only in this version.

- Demo it first. The Strategy Tester shows the panel but the buttons need a visual test.

Inputs

Risk mode and size, magic number, slippage, spread warning, management scope, break-even, partial close, trailing settings, daily loss and drawdown limits, alerts and panel position.

Trading involves risk. This is a tool, not a signal and not financial advice.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_Trade_Manager_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_Trade_Manager_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
