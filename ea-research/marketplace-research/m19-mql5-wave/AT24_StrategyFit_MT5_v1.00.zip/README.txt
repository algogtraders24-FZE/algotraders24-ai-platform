AT24 STRATEGY FIT - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Strategy Fit shows how three plain rules performed in each market state on your own symbol history, so you can see which rule has fitted the state the market is in now.

What it does

- Three plain rules are measured: trend, breakout and reversion. Each is tested on the chart symbol H1 history inside five market states (NOISY, WIDE SWING, STRONG MOVE, COMPRESSED, STEADY TREND).

- For every rule and state the panel shows the average result in units of ATR after the spread, the hit rate, the number of trades and a luck test (random sign flips of the same trades).

- A cell is marked FIT only with at least 30 trades, a positive average and a low luck value. It is marked AVOID with 30 or more trades and a negative average. Fewer than 30 trades gives no claim.

- The panel marks the state now, the class of each rule in this state, and the signal of each rule on the last closed bar.

- Optional protective stop in the measured trades. A stop caps each loss. It does not create an advantage.

- A live arrow and an optional alert appear only when a rule signals in a state where its own record is FIT. Buffers for EAs (signals, classes).

Points to know

- It measures the past. A FIT cell can be luck: with many cells some look good by chance. The number of trades and the luck test are there for that reason.

- A symbol with a strong drift can make one side look good because of the drift.

- The spread used is the current spread, swap is not included.

- Made for H1 charts. The dashboard is hidden in the Strategy Tester by default. It places no trades.

- Alerts and push messages are written but not yet tested live.

Inputs

History bars, bars read from the chart, protective stop, alerts, colours, panel corner and offsets.

Descriptive history on your broker data. Context tool, not a forecast. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_StrategyFit_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_StrategyFit_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
