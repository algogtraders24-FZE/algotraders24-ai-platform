AT24 PROP FIRM GUARD - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Prop Firm Guard watches the whole account against the rules of a challenge or funded account and closes positions before a limit is broken. It opens no trades.

What it does

- Daily loss: shows how much of your daily limit is used, with a bar and the amount left. The limit can be a percent of the initial balance or of the balance at the start of the day. You choose the server hour when the day starts.

- Maximum loss: the same for the total limit, counted from the initial balance or from the highest equity reached.

- Safety margin: a warning at one share of a limit (default 70 percent) and an action at a higher share (default 92 percent). The action closes all positions, deletes pending orders and locks the account for the rest of the day, or until you reset it for the maximum loss.

- Profit target and minimum trading days: progress is shown on the panel. Optional lock when the target is reached.

- Open risk: adds up the risk of all open positions from their stop losses, flags positions without a stop loss, and closes the newest position when your open risk limit is passed.

- Schedule: close everything on Friday from an hour you set, and close positions that were opened in your quiet hours.

- Works on the whole account: all symbols and the trades of all expert advisors and manual orders. It does not matter on which chart it runs.

- Alert and push message when a warning or action happens.

Points to know

- Rules differ between firms. Enter the numbers of your own firm and read its rules. The guard does not guarantee that an account stays inside its rules or that a challenge is passed.

- Gaps, slippage, spread and a slow connection can take the account past a limit before a close is executed. The safety margin helps, it is not a guarantee.

- When it acts it closes all positions of the account, also those of other expert advisors.

- The initial balance is taken from the balance when the guard is first attached, or from the input if you set it.

- It places no orders and gives no signals.

Inputs

Initial balance, daily loss limit and its basis, day start hour, maximum loss limit and mode, profit target, minimum days, warning and action levels, close on action, lock at target, open risk limit, Friday close hour, quiet hours, alerts and panel position.

Trading involves risk. This is a tool, not a signal and not financial advice.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_Prop_Firm_Guard_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_Prop_Firm_Guard_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
