AT24 SMC TOOLKIT - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 SMC Toolkit puts market structure, order blocks and fair value gaps on one chart and shows what price really did at these places in your own history.

What it does

- Market structure: marks BOS (break of structure) and CHoCH (change of character) from confirmed swings. A break needs a bar close beyond the level, and a swing is used only after it is confirmed, so marks do not move after they are drawn. The panel shows the current structure (up or down), the last break and the last swing high and low.

- Order blocks: marks the last opposite candle before a strong move, as zones that stay on the chart until price touches them.

- Fair value gaps: marks three-bar gaps as zones that stay on the chart until price trades through them.

- Statistics for every module on your own chart, shown in the panel: how often price kept going after a break, how often it came back to a block or gap and reacted, each one compared with a control level, so you see whether a zone behaves differently from any other level.

- Structure check: the reaction rate of order blocks when the structure agreed with the block, next to the rate when it did not.

- Zone in play: the panel tells you when price touched a zone for the first time on the last closed bar, and whether the structure agrees with that zone.

- Optional alert and push message for a CHoCH, a BOS, or a return to a zone that agrees with the structure. They are off by default.

- Works on any symbol and timeframe. Each module can be switched off, and the number of zones drawn can be set.

Points to know

- It marks zones and measures the past. It is not a trade instruction and does not promise results. A zone can fail, and the statistics can be close to what any other level gives. That is what the control values are for.

- Everything is computed on closed bars, so earlier marks stay in place.

- The indicator needs about 1200 bars of history on the chart.

- The panel is hidden in the Strategy Tester by default.

Inputs

Modules on or off, history bars, swing size, statistic bars, order block and gap detection settings, number of zones drawn, colours, alerts, panel corner and offsets.

Descriptive history on your broker data. Context tool, not a forecast. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_SmcToolkit_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_SmcToolkit_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
