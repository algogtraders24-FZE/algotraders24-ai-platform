AT24 POSITION SCANNER - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Position Scanner is one table for many symbols that shows where each one stands in a weekly structure plan, using closed bars only.

What it does

- Reads weekly and H4 history for a list of symbols (up to 24, set by you, with an optional broker suffix) and shows one row per symbol.

- Each row: the weekly trend (up, down or range), what the rules are waiting for (pullback depth, an H4 turn, or a running plan), entry, stop and target levels, the risk in weekly ATR, and the record of the same rules on that symbol with the number of cases. Under 30 cases no claim is shown.

- Symbols that have just triggered sort first.

- Optional alert on a new trigger and on an H4 turn, with an optional push message.

- Swings are used only after they are confirmed and every bar is closed, so rows do not repaint.

Points to know

- It is a planning table, not a trade instruction. A plan can fail and past results do not predict future results.

- Symbol names must exist at your broker. Add a suffix if your broker uses one. Missing symbols are skipped.

- The first load reads a lot of history and can take a short time.

- The table is hidden in the Strategy Tester by default.

- Alerts, swap in the record and lot values are not yet tested live.

Inputs

Symbol list, suffix, swing and pullback settings, stop buffer, history bars, alerts, panel corner and offsets.

Descriptive history on your broker data. Planning tool, not a forecast. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_PositionScanner_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_PositionScanner_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
