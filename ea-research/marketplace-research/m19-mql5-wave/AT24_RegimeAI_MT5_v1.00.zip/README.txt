AT24 REGIME AI - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Regime AI puts every closed H1 bar into one of five market states and shows what each state has been followed by on your own chart history.

What it does

- Five states: NOISY, WIDE SWING, STRONG MOVE, COMPRESSED and STEADY TREND. The state comes from fixed constants learned once on historical data. Nothing is learned on your chart and the state of a closed bar never changes later, so it does not repaint.

- Dashboard: the current state, how long it has lasted, how often a state stays on the next bar, and for each state the size of the next 24 hours compared with average, with the number of bars behind it.

- Expected next 24 hour range with an 80 percent band, built from the symbol history and its hour of day pattern. The panel shows how often the band held on the last part of the history. It helps size stops and targets. It does not say which way price will go.

- Weekly structure view: trend up, down or range from confirmed weekly swings, the stage, and a plan with entry, stop and target levels drawn on the chart, with the record of the same rules and the number of cases.

- Colour strip of the states in the indicator window, optional alert on a state change, and buffers for EAs (state, run length, ratio, expected range, band low, band high).

Points to know

- The states describe the size of moves, not direction. It is not a trade instruction and does not promise results.

- Made for H1 charts. Other timeframes show a notice.

- Statistics are measured on your broker data and can differ from other symbols. The number of cases is always shown.

- The dashboard is hidden in the Strategy Tester by default.

- Alerts and push messages are written but not yet tested live.

Inputs

History bars for the statistics, bars read from the chart, plan and risk settings, alerts, colours, panel corner and offsets.

Descriptive history on your broker data. Context tool, not a forecast. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_RegimeAI_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_RegimeAI_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
