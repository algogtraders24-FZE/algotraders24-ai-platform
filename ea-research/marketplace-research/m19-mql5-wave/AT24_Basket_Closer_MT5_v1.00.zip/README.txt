AT24 BASKET CLOSER - MetaTrader 5 version v1.00 (licensed Expert Advisor file)

AT24 Basket Closer closes a group of open trades with one click, or automatically at a profit target, a loss limit or a trailing basket profit.

What it does

- Panel on the chart with the number of positions, buys and sells, total lots, net profit or loss in money and in percent of balance, winners and losers, and the best and worst position.

- One-click buttons: close all, close winners, close losers, close buys, close sells. Every close button asks for a second click within four seconds, so nothing closes by accident.

- The basket can be all trades, the trades of the chart symbol, or the trades of one magic number. The scope button on the panel changes it at any time. Trades outside the basket are not touched.

- Automatic rules, switched on and off from the panel: close the basket at a profit amount or a percent of balance, at a loss amount or a percent of balance, or with a trailing basket profit that closes when the profit falls a set percent below its peak.

- When everything is closed, pending orders of the basket can be deleted as well.

- Alert and push message when an automatic rule closes the basket. The result of each close is written on the panel and to the Experts log, including trades that could not be closed.

Points to know

- It opens no trades. It only closes trades that already exist.

- Net profit includes swap. Brokers that charge commission per deal may show a slightly different final result.

- Trades are closed one after another at market price. In a fast market the prices can differ from the panel, and a close can be rejected by the broker. A trade that could not be closed is reported on the panel.

- Automatic rules work only while the chart is open and the terminal is connected. They are not a replacement for a stop loss on each trade.

- Algo trading must be allowed for the EA.

Inputs

Starting scope and magic number, delete pending orders, slippage, automatic rules (profit and loss amounts and percents, trailing start and give-back), alerts, panel position.

Utility for managing existing trades. Not financial advice. Trading leveraged products is risky.

INSTALL (MetaTrader 5)
1. In MT5 choose File > Open Data Folder, open MQL5 > Experts and copy AT24_Basket_Closer_Licensed.ex5 into it.
2. In the Navigator panel right-click Expert Advisors > Refresh.
3. Allow the licence check once per terminal: Tools > Options > Expert Advisors > tick "Allow WebRequest for listed URL" and add https://www.algotraders24.ai
4. Drag AT24_Basket_Closer_Licensed from Navigator > Expert Advisors onto a chart. On the Inputs tab paste your licence key into "InpLicenseKey" (Dashboard > Purchases > your product).
5. Keep the Algo Trading button switched on.

LICENCE
- One key works on ONE trading account at a time and only for this product. You can move it yourself from Dashboard > Purchases (2 changes per 30 days).
- The only data sent to AT24 is your key, the trading account number, the broker server name and the product name. No trade data leaves your computer.
- The key is checked at start and every 4 hours; a short internet problem does not stop it (up to 72 hours).
- The Strategy Tester needs no key.

IMPORTANT
- Personal use on your own charts. Please do not share your key or the file.
- Support: support@algotraders24.ai
